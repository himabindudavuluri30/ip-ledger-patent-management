/*
# IP Ledger - Core Schema (single-tenant demo, no auth)

1. New Tables
- `inventions`: patent ownership records with state machine status
  - id (uuid), internal_id (text unique), title, description, inventor_name,
    collaborators (text[]), organization, jurisdiction, claimed_owner,
    patent_application_number (text), status (enum), created_by_role, created_at, updated_at
- `documents`: uploaded files for an invention with SHA-256 hashes
  - id, invention_id (fk), filename, mime_type, size_bytes, sha256_hash,
    version (int), uploaded_at, uploaded_by_role, storage_ref (text), notes
- `licenses`: license records on an invention
  - id, invention_id, license_type, licensor, licensee, territory, start_date, expiry_date,
    agreement_hash, status (enum), created_at, updated_at, notes
- `transfers`: ownership transfer requests
  - id, invention_id, current_holder, proposed_recipient, agreement_hash,
    status (enum), created_at, updated_at, notes
- `disputes`: disputes raised against inventions/transfers
  - id, invention_id, transfer_id (nullable), raised_by_role, reason, status (enum), created_at, resolved_at
- `audit_events`: append-only event log
  - id, event_id (text unique), invention_id (nullable), license_id (nullable),
    transfer_id (nullable), actor_role, action, previous_state, new_state,
    transaction_id, transaction_mode (enum: SIMULATED/HYPERLEDGER_FABRIC),
    transaction_status (enum: PENDING/CONFIRMED/FAILED/UNKNOWN), timestamp, details

2. Enums
- invention_status: PROPOSED, PENDING_APPROVAL, APPROVED, RECORDED, COMPLETED, REJECTED, DISPUTED
- license_status: REQUESTED, APPROVED, REJECTED, ACTIVE, EXPIRED, TERMINATED, DISPUTED
- transfer_status: REQUESTED, APPROVED, REJECTED, COMPLETED, DISPUTED, CANCELLED
- dispute_status: OPEN, RESOLVED, DISMISSED
- transaction_mode: SIMULATED, HYPERLEDGER_FABRIC
- transaction_status: PENDING, CONFIRMED, FAILED, UNKNOWN

3. Security
- Single-tenant demo app (no sign-in). Enable RLS on all tables.
- Grant CRUD to anon + authenticated on all tables (intentionally shared demo data).
- All policies use USING (true) / WITH CHECK (true) because data is intentionally public demo data.
*/

DO $$ BEGIN
  CREATE TYPE invention_status AS ENUM ('PROPOSED','PENDING_APPROVAL','APPROVED','RECORDED','COMPLETED','REJECTED','DISPUTED');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE license_status AS ENUM ('REQUESTED','APPROVED','REJECTED','ACTIVE','EXPIRED','TERMINATED','DISPUTED');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE transfer_status AS ENUM ('REQUESTED','APPROVED','REJECTED','COMPLETED','DISPUTED','CANCELLED');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE dispute_status AS ENUM ('OPEN','RESOLVED','DISMISSED');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE transaction_mode AS ENUM ('SIMULATED','HYPERLEDGER_FABRIC');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE transaction_status AS ENUM ('PENDING','CONFIRMED','FAILED','UNKNOWN');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

CREATE TABLE IF NOT EXISTS inventions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  internal_id text UNIQUE NOT NULL,
  title text NOT NULL,
  description text,
  inventor_name text NOT NULL,
  collaborators text[] DEFAULT '{}',
  organization text,
  jurisdiction text,
  claimed_owner text,
  patent_application_number text,
  status invention_status NOT NULL DEFAULT 'PROPOSED',
  created_by_role text NOT NULL DEFAULT 'Inventor',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS documents (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  invention_id uuid NOT NULL REFERENCES inventions(id) ON DELETE CASCADE,
  filename text NOT NULL,
  mime_type text,
  size_bytes bigint,
  sha256_hash text NOT NULL,
  version int NOT NULL DEFAULT 1,
  uploaded_at timestamptz DEFAULT now(),
  uploaded_by_role text NOT NULL DEFAULT 'Inventor',
  storage_ref text,
  notes text
);

CREATE TABLE IF NOT EXISTS licenses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  invention_id uuid NOT NULL REFERENCES inventions(id) ON DELETE CASCADE,
  license_type text,
  licensor text,
  licensee text,
  territory text,
  start_date date,
  expiry_date date,
  agreement_hash text,
  status license_status NOT NULL DEFAULT 'REQUESTED',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  notes text
);

CREATE TABLE IF NOT EXISTS transfers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  invention_id uuid NOT NULL REFERENCES inventions(id) ON DELETE CASCADE,
  current_holder text,
  proposed_recipient text,
  agreement_hash text,
  status transfer_status NOT NULL DEFAULT 'REQUESTED',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  notes text
);

CREATE TABLE IF NOT EXISTS disputes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  invention_id uuid NOT NULL REFERENCES inventions(id) ON DELETE CASCADE,
  transfer_id uuid REFERENCES transfers(id) ON DELETE CASCADE,
  raised_by_role text,
  reason text,
  status dispute_status NOT NULL DEFAULT 'OPEN',
  created_at timestamptz DEFAULT now(),
  resolved_at timestamptz
);

CREATE TABLE IF NOT EXISTS audit_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  event_id text UNIQUE NOT NULL,
  invention_id uuid REFERENCES inventions(id) ON DELETE CASCADE,
  license_id uuid REFERENCES licenses(id) ON DELETE CASCADE,
  transfer_id uuid REFERENCES transfers(id) ON DELETE CASCADE,
  actor_role text,
  action text NOT NULL,
  previous_state text,
  new_state text,
  transaction_id text,
  transaction_mode transaction_mode NOT NULL DEFAULT 'SIMULATED',
  transaction_status transaction_status NOT NULL DEFAULT 'CONFIRMED',
  timestamp timestamptz DEFAULT now(),
  details text
);

CREATE INDEX IF NOT EXISTS idx_documents_invention_id ON documents(invention_id);
CREATE INDEX IF NOT EXISTS idx_licenses_invention_id ON licenses(invention_id);
CREATE INDEX IF NOT EXISTS idx_transfers_invention_id ON transfers(invention_id);
CREATE INDEX IF NOT EXISTS idx_disputes_invention_id ON disputes(invention_id);
CREATE INDEX IF NOT EXISTS idx_audit_invention_id ON audit_events(invention_id);
CREATE INDEX IF NOT EXISTS idx_audit_event_id ON audit_events(event_id);
CREATE INDEX IF NOT EXISTS idx_inventions_status ON inventions(status);

ALTER TABLE inventions ENABLE ROW LEVEL SECURITY;
ALTER TABLE documents ENABLE ROW LEVEL SECURITY;
ALTER TABLE licenses ENABLE ROW LEVEL SECURITY;
ALTER TABLE transfers ENABLE ROW LEVEL SECURITY;
ALTER TABLE disputes ENABLE ROW LEVEL SECURITY;
ALTER TABLE audit_events ENABLE ROW LEVEL SECURITY;

-- Single-tenant demo: all data intentionally shared. Grant CRUD to anon + authenticated.
GRANT SELECT, INSERT, UPDATE, DELETE ON inventions, documents, licenses, transfers, disputes, audit_events TO anon, authenticated;

-- Inventions
DROP POLICY IF EXISTS "anon_select_inventions" ON inventions; CREATE POLICY "anon_select_inventions" ON inventions FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_inventions" ON inventions; CREATE POLICY "anon_insert_inventions" ON inventions FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_inventions" ON inventions; CREATE POLICY "anon_update_inventions" ON inventions FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_inventions" ON inventions; CREATE POLICY "anon_delete_inventions" ON inventions FOR DELETE TO anon, authenticated USING (true);

-- Documents
DROP POLICY IF EXISTS "anon_select_documents" ON documents; CREATE POLICY "anon_select_documents" ON documents FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_documents" ON documents; CREATE POLICY "anon_insert_documents" ON documents FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_documents" ON documents; CREATE POLICY "anon_update_documents" ON documents FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_documents" ON documents; CREATE POLICY "anon_delete_documents" ON documents FOR DELETE TO anon, authenticated USING (true);

-- Licenses
DROP POLICY IF EXISTS "anon_select_licenses" ON licenses; CREATE POLICY "anon_select_licenses" ON licenses FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_licenses" ON licenses; CREATE POLICY "anon_insert_licenses" ON licenses FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_licenses" ON licenses; CREATE POLICY "anon_update_licenses" ON licenses FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_licenses" ON licenses; CREATE POLICY "anon_delete_licenses" ON licenses FOR DELETE TO anon, authenticated USING (true);

-- Transfers
DROP POLICY IF EXISTS "anon_select_transfers" ON transfers; CREATE POLICY "anon_select_transfers" ON transfers FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_transfers" ON transfers; CREATE POLICY "anon_insert_transfers" ON transfers FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_transfers" ON transfers; CREATE POLICY "anon_update_transfers" ON transfers FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_transfers" ON transfers; CREATE POLICY "anon_delete_transfers" ON transfers FOR DELETE TO anon, authenticated USING (true);

-- Disputes
DROP POLICY IF EXISTS "anon_select_disputes" ON disputes; CREATE POLICY "anon_select_disputes" ON disputes FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_disputes" ON disputes; CREATE POLICY "anon_insert_disputes" ON disputes FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_disputes" ON disputes; CREATE POLICY "anon_update_disputes" ON disputes FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_disputes" ON disputes; CREATE POLICY "anon_delete_disputes" ON disputes FOR DELETE TO anon, authenticated USING (true);

-- Audit events (append-only intended at app layer; CRUD granted for demo)
DROP POLICY IF EXISTS "anon_select_audit_events" ON audit_events; CREATE POLICY "anon_select_audit_events" ON audit_events FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_audit_events" ON audit_events; CREATE POLICY "anon_insert_audit_events" ON audit_events FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_audit_events" ON audit_events; CREATE POLICY "anon_update_audit_events" ON audit_events FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_audit_events" ON audit_events; CREATE POLICY "anon_delete_audit_events" ON audit_events FOR DELETE TO anon, authenticated USING (true);
