import type { TransactionMode, TransactionStatus } from './supabase';

// Blockchain integration layer. Mode A (SIMULATION) works out of the box.
// Mode B (HYPERLEDGER_FABRIC) requires a configured Fabric network — when not
// connected, the app stays in SIMULATION mode and never fabricates Fabric data.

export interface TransactionResult {
  transaction_id: string;
  mode: TransactionMode;
  status: TransactionStatus;
  block_number?: number;
  timestamp: string;
}

const STORAGE_KEY = 'ip_ledger_fabric_mode';

export function getMode(): TransactionMode {
  // Fabric is only enabled if an admin explicitly verified a real connection.
  // Default is always SIMULATION. We never auto-enable FABRIC on a successful
  // mock/simulated response.
  try {
    const v = localStorage.getItem(STORAGE_KEY);
    if (v === 'HYPERLEDGER_FABRIC') return 'HYPERLEDGER_FABRIC';
  } catch {}
  return 'SIMULATED';
}

export function setMode(mode: TransactionMode) {
  try {
    localStorage.setItem(STORAGE_KEY, mode);
  } catch {}
}

export function isFabricConnected(): boolean {
  return getMode() === 'HYPERLEDGER_FABRIC';
}

function randomId(prefix: string): string {
  const hex = Array.from({ length: 16 }, () =>
    Math.floor(Math.random() * 256).toString(16).padStart(2, '0')
  ).join('');
  return `${prefix}-${hex}`;
}

// Submit a simulated transaction. Returns a SIMULATED transaction id.
// Note: We deliberately do NOT fabricate block numbers, peer endorsements,
// or cryptographic proofs. Simulated ids are visibly labeled SIMULATED.
export async function submitSimulatedTransaction(
  action: string,
  options: { simulateFailure?: boolean; simulateTimeout?: boolean } = {}
): Promise<TransactionResult> {
  await new Promise((r) => setTimeout(r, 350 + Math.random() * 250));

  if (options.simulateTimeout) {
    // Caller should reconcile via reconcileTransaction.
    return {
      transaction_id: randomId('simtx'),
      mode: 'SIMULATED',
      status: 'PENDING',
      timestamp: new Date().toISOString(),
    };
  }

  if (options.simulateFailure) {
    return {
      transaction_id: randomId('simtx'),
      mode: 'SIMULATED',
      status: 'FAILED',
      timestamp: new Date().toISOString(),
    };
  }

  return {
    transaction_id: randomId('simtx'),
    mode: 'SIMULATED',
    status: 'CONFIRMED',
    timestamp: new Date().toISOString(),
  };
}

// Reconcile a PENDING/UNKNOWN transaction — for timeout handling.
// In simulation, a PENDING tx is confirmed on reconcile.
export async function reconcileTransaction(
  transactionId: string,
  mode: TransactionMode
): Promise<TransactionResult> {
  await new Promise((r) => setTimeout(r, 200));
  return {
    transaction_id: transactionId,
    mode,
    status: 'CONFIRMED',
    timestamp: new Date().toISOString(),
  };
}

// Idempotency key generator for write requests.
export function idempotencyKey(): string {
  return randomId('idem');
}

export function generateEventId(): string {
  return 'EVT-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 8);
}

export function generateInternalInventionId(): string {
  const year = new Date().getFullYear();
  const n = Math.floor(1000 + Math.random() * 9000);
  return `IP-${year}-${n}`;
}
