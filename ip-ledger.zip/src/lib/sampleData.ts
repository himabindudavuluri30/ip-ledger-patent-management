import { supabase } from './supabase';
import { sha256OfText } from './crypto';
import { logAudit } from './audit';
import { generateInternalInventionId, getMode } from './blockchain';
import type { Role } from './supabase';

// Sample DEMO DATA — fictional organizations and people. Clearly labeled.
// These are NOT actual patents.

interface SampleInvention {
  internal_id: string;
  title: string;
  description: string;
  inventor_name: string;
  collaborators: string[];
  organization: string;
  jurisdiction: string;
  claimed_owner: string;
  patent_application_number: string;
  status: 'PROPOSED' | 'PENDING_APPROVAL' | 'APPROVED' | 'RECORDED' | 'COMPLETED';
  notes: string;
}

const SAMPLE_INVENTIONS: SampleInvention[] = [
  {
    internal_id: 'IP-2024-1001',
    title: 'Smart Irrigation Controller',
    description:
      'DEMO DATA. A soil-moisture-aware irrigation controller that adjusts watering schedules using edge sensor data and weather forecasts to reduce water consumption.',
    inventor_name: 'Dr. Alex Hartman',
    collaborators: ['Priya Nair', 'Marco Silvia'],
    organization: 'Verdant Labs (fictional)',
    jurisdiction: 'United States',
    claimed_owner: 'Verdant Labs (fictional)',
    patent_application_number: 'US-DEMO-2024-000001',
    status: 'APPROVED',
    notes: 'DEMO DATA: prototype evaluation complete.',
  },
  {
    internal_id: 'IP-2024-1002',
    title: 'AI-Based Speech Recognition System',
    description:
      'DEMO DATA. A low-latency speech recognition system optimized for noisy environments using a compact transformer model with on-device inference.',
    inventor_name: 'Dr. Lin Zhao',
    collaborators: ['Sam Okafor'],
    organization: 'Northwind AI (fictional)',
    jurisdiction: 'European Union',
    claimed_owner: 'Northwind AI (fictional)',
    patent_application_number: 'EP-DEMO-2024-000002',
    status: 'PENDING_APPROVAL',
    notes: 'DEMO DATA: pending IP committee review.',
  },
  {
    internal_id: 'IP-2024-1003',
    title: 'Energy-Efficient Battery Management System',
    description:
      'DEMO DATA. A battery management system that extends cycle life by dynamically balancing cell loads based on thermal and impedance measurements.',
    inventor_name: 'Dr. Maria Santos',
    collaborators: ['Jonas Berg'],
    organization: 'Helios Energy (fictional)',
    jurisdiction: 'United States',
    claimed_owner: 'Helios Energy (fictional)',
    patent_application_number: 'US-DEMO-2024-000003',
    status: 'RECORDED',
    notes: 'DEMO DATA: recorded to ledger; awaiting completion of licensing terms.',
  },
];

export async function loadSampleData(): Promise<{ created: number; skipped: number }> {
  let created = 0;
  let skipped = 0;

  for (const s of SAMPLE_INVENTIONS) {
    // Skip if already exists by internal_id
    const { data: existing } = await supabase
      .from('inventions')
      .select('id')
      .eq('internal_id', s.internal_id)
      .maybeSingle();
    if (existing) {
      skipped++;
      continue;
    }

    const { data: inv, error } = await supabase
      .from('inventions')
      .insert({
        internal_id: s.internal_id,
        title: s.title,
        description: s.description,
        inventor_name: s.inventor_name,
        collaborators: s.collaborators,
        organization: s.organization,
        jurisdiction: s.jurisdiction,
        claimed_owner: s.claimed_owner,
        patent_application_number: s.patent_application_number,
        status: s.status,
        created_by_role: 'Inventor' as Role,
      })
      .select()
      .maybeSingle();

    if (error || !inv) {
      console.error('Sample insert failed:', error);
      continue;
    }
    created++;

    // Add a notes document with hash
    const notesHash = await sha256OfText(s.notes);
    await supabase.from('documents').insert({
      invention_id: inv.id,
      filename: 'demo-supporting-notes.txt',
      mime_type: 'text/plain',
      size_bytes: new Blob([s.notes]).size,
      sha256_hash: notesHash,
      version: 1,
      uploaded_by_role: 'Inventor',
      storage_ref: null,
      notes: s.notes,
    });

    await logAudit({
      invention_id: inv.id,
      actor_role: 'Inventor',
      action: 'LOAD_SAMPLE_DATA',
      previous_state: null,
      new_state: s.status,
      details: `DEMO DATA loaded: ${s.title}. Mode: ${getMode()}.`,
    });
  }

  return { created, skipped };
}

export async function clearAllData(): Promise<void> {
  // Order respects FK constraints; audit_events last.
  await supabase.from('audit_events').delete().neq('id', '00000000-0000-0000-0000-000000000000');
  await supabase.from('disputes').delete().neq('id', '00000000-0000-0000-0000-000000000000');
  await supabase.from('transfers').delete().neq('id', '00000000-0000-0000-0000-000000000000');
  await supabase.from('licenses').delete().neq('id', '00000000-0000-0000-0000-000000000000');
  await supabase.from('documents').delete().neq('id', '00000000-0000-0000-0000-000000000000');
  await supabase.from('inventions').delete().neq('id', '00000000-0000-0000-0000-000000000000');
}
