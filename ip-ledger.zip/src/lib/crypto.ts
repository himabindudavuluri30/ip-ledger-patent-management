// SHA-256 hashing using the Web Crypto API (SubtleCrypto).
// Works in modern browsers and Deno. No external dependencies.

export async function sha256OfFile(file: File | Blob): Promise<string> {
  const buffer = await file.arrayBuffer();
  return sha256OfBuffer(buffer);
}

export async function sha256OfBuffer(buffer: ArrayBuffer): Promise<string> {
  const digest = await crypto.subtle.digest('SHA-256', buffer);
  return bufferToHex(digest);
}

export async function sha256OfText(text: string): Promise<string> {
  const encoder = new TextEncoder();
  const buffer = encoder.encode(text);
  return sha256OfBuffer(buffer.buffer);
}

function bufferToHex(buffer: ArrayBuffer): string {
  const bytes = new Uint8Array(buffer);
  let hex = '';
  for (let i = 0; i < bytes.length; i++) {
    hex += bytes[i].toString(16).padStart(2, '0');
  }
  return hex;
}
