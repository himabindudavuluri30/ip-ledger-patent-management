import { supabase } from './supabase';
import type { Invention, AuditEvent } from './supabase';
import { logAudit } from './audit';
import { generateInternalInventionId, getMode } from './blockchain';
import { sha256OfFile, sha256OfText } from './crypto';
import type { Role } from './supabase';

export interface RegisterInventionInput {
  title: string;
  description: string;
  inventor_name: string;
  collaborators: string[];
  organization: string;
  jurisdiction: string;
  claimed_owner: string;
  patent_application_number: string;
  notes: string;
  files: File[];
  actorRole: Role;
}

export interface RegisterResult {
  invention: Invention;
  documents: { filename: string; sha256_hash: string; version: number }[];
  audit: AuditEvent | null;
  duplicate: boolean;
}

const MAX_FILE_SIZE = 20 * 1024 * 1024; // 20MB
const ALLOWED_MIME = [
  'application/pdf',
  'text/plain',
  'text/markdown',
  'application/msword',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  'image/png',
  'image/jpeg',
  'image/webp',
  'application/json',
];

export interface FileValidationError {
  filename: string;
  reason: string;
}

export function validateFiles(files: File[]): FileValidationError[] {
  const errors: FileValidationError[] = [];
  for (const f of files) {
    if (f.size > MAX_FILE_SIZE) {
      errors.push({ filename: f.name, reason: 'File exceeds 20MB limit' });
    }
    if (f.type && !ALLOWED_MIME.includes(f.type)) {
      errors.push({ filename: f.name, reason: `File type ${f.type} not allowed` });
    }
  }
  return errors;
}

// Check for duplicate title + inventor_name combination.
export async function checkDuplicate(title: string, inventorName: string): Promise<boolean> {
  const { data } = await supabase
    .from('inventions')
    .select('id')
    .eq('title', title)
    .eq('inventor_name', inventorName)
    .maybeSingle();
  return !!data;
}

export async function registerInvention(input: RegisterInventionInput): Promise<RegisterResult> {
  const duplicate = await checkDuplicate(input.title, input.inventor_name);
  if (duplicate) {
    throw new Error('Duplicate invention submission: an invention with this title and inventor already exists.');
  }

  const fileErrors = validateFiles(input.files);
  if (fileErrors.length > 0) {
    throw new Error(`Invalid file upload: ${fileErrors[0].filename} — ${fileErrors[0].reason}`);
  }

  const internalId = generateInternalInventionId();
  const { data: inv, error } = await supabase
    .from('inventions')
    .insert({
      internal_id: internalId,
      title: input.title,
      description: input.description || null,
      inventor_name: input.inventor_name,
      collaborators: input.collaborators.filter(Boolean),
      organization: input.organization || null,
      jurisdiction: input.jurisdiction || null,
      claimed_owner: input.claimed_owner || null,
      patent_application_number: input.patent_application_number || null,
      status: 'PROPOSED',
      created_by_role: input.actorRole,
    })
    .select()
    .maybeSingle();

  if (error || !inv) {
    throw new Error(`Database failure: ${error?.message ?? 'unknown error'}`);
  }

  const invention = inv as Invention;
  const documents: RegisterResult['documents'] = [];

  for (let i = 0; i < input.files.length; i++) {
    const file = input.files[i];
    const hash = await sha256OfFile(file);
    const version = i + 1;
    // In this hosted demo we do NOT upload the actual file content to public
    // storage — only its hash and metadata are persisted. This avoids leaking
    // confidential invention documents.
    const { error: docErr } = await supabase.from('documents').insert({
      invention_id: invention.id,
      filename: file.name,
      mime_type: file.type || null,
      size_bytes: file.size,
      sha256_hash: hash,
      version,
      uploaded_by_role: input.actorRole,
      storage_ref: null,
      notes: input.notes || null,
    });
    if (docErr) {
      throw new Error(`Failed to store document ${file.name}: ${docErr.message}`);
    }
    documents.push({ filename: file.name, sha256_hash: hash, version });
  }

  // If there's a notes field with no files, store a notes-only document with hash of notes.
  if (input.files.length === 0 && input.notes) {
    const notesHash = await sha256OfText(input.notes);
    const { error: docErr } = await supabase.from('documents').insert({
      invention_id: invention.id,
      filename: 'supporting-notes.txt',
      mime_type: 'text/plain',
      size_bytes: new Blob([input.notes]).size,
      sha256_hash: notesHash,
      version: 1,
      uploaded_by_role: input.actorRole,
      storage_ref: null,
      notes: input.notes,
    });
    if (docErr) throw new Error(`Failed to store notes: ${docErr.message}`);
    documents.push({ filename: 'supporting-notes.txt', sha256_hash: notesHash, version: 1 });
  }

  const audit = await logAudit({
    invention_id: invention.id,
    actor_role: input.actorRole,
    action: 'REGISTER_INVENTION',
    previous_state: null,
    new_state: 'PROPOSED',
    details: `Invention "${invention.title}" registered with internal id ${invention.internal_id}. Mode: ${getMode()}.`,
  });

  return { invention, documents, audit, duplicate: false };
}

// Transition invention status with authorized action check.
export async function transitionInvention(
  invention: Invention,
  newStatus: Invention['status'],
  actorRole: Role,
  reason?: string
): Promise<Invention> {
  // Authorization checks
  if (
    (newStatus === 'APPROVED' || newStatus === 'REJECTED') &&
    !['Institution/IP Administrator', 'Auditor'].includes(actorRole)
  ) {
    const audit = await logAudit({
      invention_id: invention.id,
      actor_role: actorRole,
      action: `UNAUTHORIZED_${newStatus}_ATTEMPT`,
      previous_state: invention.status,
      new_state: invention.status,
      details: `Role ${actorRole} attempted unauthorized ${newStatus} action.`,
    });
    void audit;
    throw new Error(`Unauthorized: role ${actorRole} cannot ${newStatus.toLowerCase()} inventions.`);
  }

  const { data, error } = await supabase
    .from('inventions')
    .update({ status: newStatus, updated_at: new Date().toISOString() })
    .eq('id', invention.id)
    .select()
    .maybeSingle();

  if (error || !data) {
    throw new Error(`Database failure: ${error?.message ?? 'unknown error'}`);
  }

  const updated = data as Invention;
  const action =
    newStatus === 'APPROVED'
      ? 'APPROVE_INVENTION'
      : newStatus === 'REJECTED'
      ? 'REJECT_INVENTION'
      : newStatus === 'DISPUTED'
      ? 'DISPUTE_INVENTION'
      : newStatus === 'RECORDED'
      ? 'RECORD_INVENTION'
      : newStatus === 'COMPLETED'
      ? 'COMPLETE_INVENTION'
      : newStatus === 'PENDING_APPROVAL'
      ? 'SUBMIT_FOR_APPROVAL'
      : 'TRANSITION';

  await logAudit({
    invention_id: invention.id,
    actor_role: actorRole,
    action,
    previous_state: invention.status,
    new_state: newStatus,
    details: reason ?? `Status transitioned from ${invention.status} to ${newStatus}.`,
  });

  return updated;
}
