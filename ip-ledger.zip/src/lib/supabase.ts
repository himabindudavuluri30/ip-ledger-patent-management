import { createClient } from '@supabase/supabase-js';

const supabaseUrl = (import.meta.env.VITE_SUPABASE_URL as string) || '';
const supabaseAnonKey = (import.meta.env.VITE_SUPABASE_ANON_KEY as string) || '';

if (!supabaseUrl || !supabaseAnonKey) {
  console.error(
    'Supabase env vars missing. Check that VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY are set at build time.'
  );
}

export const supabase = createClient(
  supabaseUrl || 'https://placeholder.supabase.co',
  supabaseAnonKey || 'placeholder-anon-key',
  { auth: { persistSession: false } }
);

export type InventionStatus =
  | 'PROPOSED' | 'PENDING_APPROVAL' | 'APPROVED' | 'RECORDED' | 'COMPLETED' | 'REJECTED' | 'DISPUTED';

export type LicenseStatus =
  | 'REQUESTED' | 'APPROVED' | 'REJECTED' | 'ACTIVE' | 'EXPIRED' | 'TERMINATED' | 'DISPUTED';

export type TransferStatus =
  | 'REQUESTED' | 'APPROVED' | 'REJECTED' | 'COMPLETED' | 'DISPUTED' | 'CANCELLED';

export type DisputeStatus = 'OPEN' | 'RESOLVED' | 'DISMISSED';

export type TransactionMode = 'SIMULATED' | 'HYPERLEDGER_FABRIC';
export type TransactionStatus = 'PENDING' | 'CONFIRMED' | 'FAILED' | 'UNKNOWN';

export type Role = 'Inventor' | 'Institution/IP Administrator' | 'Rights Holder' | 'Licensee' | 'Auditor';

export const ROLES: Role[] = [
  'Inventor',
  'Institution/IP Administrator',
  'Rights Holder',
  'Licensee',
  'Auditor',
];

export interface Invention {
  id: string;
  internal_id: string;
  title: string;
  description: string | null;
  inventor_name: string;
  collaborators: string[] | null;
  organization: string | null;
  jurisdiction: string | null;
  claimed_owner: string | null;
  patent_application_number: string | null;
  status: InventionStatus;
  created_by_role: string;
  created_at: string;
  updated_at: string;
}

export interface DocumentRecord {
  id: string;
  invention_id: string;
  filename: string;
  mime_type: string | null;
  size_bytes: number | null;
  sha256_hash: string;
  version: number;
  uploaded_at: string;
  uploaded_by_role: string;
  storage_ref: string | null;
  notes: string | null;
}

export interface License {
  id: string;
  invention_id: string;
  license_type: string | null;
  licensor: string | null;
  licensee: string | null;
  territory: string | null;
  start_date: string | null;
  expiry_date: string | null;
  agreement_hash: string | null;
  status: LicenseStatus;
  created_at: string;
  updated_at: string;
  notes: string | null;
}

export interface Transfer {
  id: string;
  invention_id: string;
  current_holder: string | null;
  proposed_recipient: string | null;
  agreement_hash: string | null;
  status: TransferStatus;
  created_at: string;
  updated_at: string;
  notes: string | null;
}

export interface Dispute {
  id: string;
  invention_id: string;
  transfer_id: string | null;
  raised_by_role: string | null;
  reason: string | null;
  status: DisputeStatus;
  created_at: string;
  resolved_at: string | null;
}

export interface AuditEvent {
  id: string;
  event_id: string;
  invention_id: string | null;
  license_id: string | null;
  transfer_id: string | null;
  actor_role: string | null;
  action: string;
  previous_state: string | null;
  new_state: string | null;
  transaction_id: string | null;
  transaction_mode: TransactionMode;
  transaction_status: TransactionStatus;
  timestamp: string;
  details: string | null;
}
