import { supabase } from './supabase';
import { registerInvention, validateFiles, checkDuplicate } from './inventions';
import { transitionInvention } from './inventions';
import {
  createLicense,
  transitionLicense,
  createTransfer,
  transitionTransfer,
  raiseDispute,
} from './workflows';
import { getMode, submitSimulatedTransaction, reconcileTransaction } from './blockchain';
import { sha256OfText } from './crypto';
import type { Role } from './supabase';

export interface TestResult {
  id: number;
  name: string;
  category: 'SIMULATION TESTS' | 'FABRIC INTEGRATION TESTS';
  status: 'PASS' | 'FAIL' | 'SKIPPED';
  expected: string;
  actual: string;
  timestamp: string;
  error?: string;
}

function makeFile(name: string, content: string): File {
  return new File([content], name, { type: 'text/plain' });
}

export async function runAllTests(): Promise<TestResult[]> {
  const results: TestResult[] = [];
  const category: 'SIMULATION TESTS' | 'FABRIC INTEGRATION TESTS' =
    getMode() === 'HYPERLEDGER_FABRIC' ? 'FABRIC INTEGRATION TESTS' : 'SIMULATION TESTS';
  const now = () => new Date().toISOString();
  const role: Role = 'Inventor';
  const adminRole: Role = 'Institution/IP Administrator';
  const rightsRole: Role = 'Rights Holder';

  // Test 1: Valid invention registration
  try {
    const t1Title = `Test Invention ${Date.now()}`;
    const res = await registerInvention({
      title: t1Title,
      description: 'Test description',
      inventor_name: 'Test Inventor',
      collaborators: ['Collab One'],
      organization: 'Test Org',
      jurisdiction: 'US',
      claimed_owner: 'Test Org',
      patent_application_number: '',
      notes: 'Test notes',
      files: [makeFile('test.txt', 'hello world')],
      actorRole: role,
    });
    const pass = !!res.invention && res.invention.status === 'PROPOSED';
    results.push({
      id: 1,
      name: 'Valid invention registration',
      category,
      status: pass ? 'PASS' : 'FAIL',
      expected: 'Invention created with status PROPOSED',
      actual: pass ? `Created ${res.invention.internal_id} as PROPOSED` : 'Not PROPOSED',
      timestamp: now(),
    });
  } catch (e) {
    results.push({ id: 1, name: 'Valid invention registration', category, status: 'FAIL', expected: 'Invention created with status PROPOSED', actual: 'Error', timestamp: now(), error: String(e) });
  }

  // Test 2: Duplicate invention submission
  try {
    const dupTitle = `Dup Test ${Date.now()}`;
    await registerInvention({
      title: dupTitle, description: 'd', inventor_name: 'Dup Inventor', collaborators: [],
      organization: 'O', jurisdiction: 'US', claimed_owner: 'O', patent_application_number: '',
      notes: 'n', files: [], actorRole: role,
    });
    let threw = false;
    try {
      await registerInvention({
        title: dupTitle, description: 'd', inventor_name: 'Dup Inventor', collaborators: [],
        organization: 'O', jurisdiction: 'US', claimed_owner: 'O', patent_application_number: '',
        notes: 'n', files: [], actorRole: role,
      });
    } catch {
      threw = true;
    }
    const isDup = await checkDuplicate(dupTitle, 'Dup Inventor');
    results.push({
      id: 2, name: 'Duplicate invention submission', category,
      status: threw && isDup ? 'PASS' : 'FAIL',
      expected: 'Duplicate submission rejected',
      actual: threw ? 'Duplicate correctly rejected' : 'Duplicate was NOT rejected',
      timestamp: now(),
    });
  } catch (e) {
    results.push({ id: 2, name: 'Duplicate invention submission', category, status: 'FAIL', expected: 'Duplicate submission rejected', actual: 'Error', timestamp: now(), error: String(e) });
  }

  // Test 3: Valid SHA-256 hash calculation
  try {
    const h = await sha256OfText('abc');
    // Known SHA-256 of 'abc'
    const expected = 'ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad';
    results.push({
      id: 3, name: 'Valid SHA-256 hash calculation', category,
      status: h === expected ? 'PASS' : 'FAIL',
      expected: expected, actual: h, timestamp: now(),
    });
  } catch (e) {
    results.push({ id: 3, name: 'Valid SHA-256 hash calculation', category, status: 'FAIL', expected: 'known hash', actual: 'Error', timestamp: now(), error: String(e) });
  }

  // Test 4 & 5: Document verification match and mismatch
  try {
    const original = 'confidential invention disclosure v1';
    const h1 = await sha256OfText(original);
    const modified = 'confidential invention disclosure v2 (tampered)';
    const h2 = await sha256OfText(modified);
    results.push({
      id: 4, name: 'Matching document verification', category,
      status: h1 === h1 ? 'PASS' : 'FAIL',
      expected: 'Hashes match', actual: h1 === h1 ? 'MATCH' : 'MISMATCH', timestamp: now(),
    });
    results.push({
      id: 5, name: 'Modified document hash mismatch', category,
      status: h1 !== h2 ? 'PASS' : 'FAIL',
      expected: 'Hashes differ', actual: h1 !== h2 ? 'MISMATCH' : 'MATCH', timestamp: now(),
    });
  } catch (e) {
    results.push({ id: 4, name: 'Matching document verification', category, status: 'FAIL', expected: 'match', actual: 'Error', timestamp: now(), error: String(e) });
    results.push({ id: 5, name: 'Modified document hash mismatch', category, status: 'FAIL', expected: 'mismatch', actual: 'Error', timestamp: now(), error: String(e) });
  }

  // Test 6: Unauthorized approval attempt
  try {
    const inv = await registerInvention({
      title: `Auth Test ${Date.now()}`, description: 'd', inventor_name: 'Auth Inv', collaborators: [],
      organization: 'O', jurisdiction: 'US', claimed_owner: 'O', patent_application_number: '',
      notes: 'n', files: [], actorRole: role,
    });
    // Submit for approval first
    await transitionInvention(inv.invention, 'PENDING_APPROVAL', adminRole);
    const { data: pending } = await supabase.from('inventions').select('*').eq('id', inv.invention.id).maybeSingle();
    let threw = false;
    try {
      // Inventor attempts to approve — should be unauthorized
      await transitionInvention({ ...inv.invention, status: 'PENDING_APPROVAL' }, 'APPROVED', role);
    } catch {
      threw = true;
    }
    results.push({
      id: 6, name: 'Unauthorized approval attempt', category,
      status: threw ? 'PASS' : 'FAIL',
      expected: 'Inventor cannot approve', actual: threw ? 'Correctly blocked' : 'Was NOT blocked',
      timestamp: now(),
    });
  } catch (e) {
    results.push({ id: 6, name: 'Unauthorized approval attempt', category, status: 'FAIL', expected: 'blocked', actual: 'Error', timestamp: now(), error: String(e) });
  }

  // Test 7: Valid approval workflow
  try {
    const inv = await registerInvention({
      title: `Approve Test ${Date.now()}`, description: 'd', inventor_name: 'Appr Inv', collaborators: [],
      organization: 'O', jurisdiction: 'US', claimed_owner: 'O', patent_application_number: '',
      notes: 'n', files: [], actorRole: role,
    });
    await transitionInvention(inv.invention, 'PENDING_APPROVAL', adminRole);
    const approved = await transitionInvention({ ...inv.invention, status: 'PENDING_APPROVAL' }, 'APPROVED', adminRole);
    results.push({
      id: 7, name: 'Valid approval workflow', category,
      status: approved.status === 'APPROVED' ? 'PASS' : 'FAIL',
      expected: 'Status APPROVED', actual: approved.status, timestamp: now(),
    });
  } catch (e) {
    results.push({ id: 7, name: 'Valid approval workflow', category, status: 'FAIL', expected: 'APPROVED', actual: 'Error', timestamp: now(), error: String(e) });
  }

  // Test 8: Rejection workflow
  try {
    const inv = await registerInvention({
      title: `Reject Test ${Date.now()}`, description: 'd', inventor_name: 'Rej Inv', collaborators: [],
      organization: 'O', jurisdiction: 'US', claimed_owner: 'O', patent_application_number: '',
      notes: 'n', files: [], actorRole: role,
    });
    await transitionInvention(inv.invention, 'PENDING_APPROVAL', adminRole);
    const rejected = await transitionInvention({ ...inv.invention, status: 'PENDING_APPROVAL' }, 'REJECTED', adminRole);
    results.push({
      id: 8, name: 'Rejection workflow', category,
      status: rejected.status === 'REJECTED' ? 'PASS' : 'FAIL',
      expected: 'Status REJECTED', actual: rejected.status, timestamp: now(),
    });
  } catch (e) {
    results.push({ id: 8, name: 'Rejection workflow', category, status: 'FAIL', expected: 'REJECTED', actual: 'Error', timestamp: now(), error: String(e) });
  }

  // Test 9: Disputed transfer blocked
  try {
    const inv = await registerInvention({
      title: `Dispute Test ${Date.now()}`, description: 'd', inventor_name: 'Disp Inv', collaborators: [],
      organization: 'O', jurisdiction: 'US', claimed_owner: 'O', patent_application_number: '',
      notes: 'n', files: [], actorRole: role,
    });
    await transitionInvention(inv.invention, 'PENDING_APPROVAL', adminRole);
    await transitionInvention({ ...inv.invention, status: 'PENDING_APPROVAL' }, 'APPROVED', adminRole);
    const { data: apprInv } = await supabase.from('inventions').select('*').eq('id', inv.invention.id).maybeSingle();
    const transfer = await createTransfer({
      invention_id: inv.invention.id, current_holder: 'O', proposed_recipient: 'New Owner',
      notes: 'transfer', actorRole: rightsRole,
    });
    await transitionTransfer(transfer, apprInv as any, 'APPROVED', adminRole);
    // Raise dispute
    await raiseDispute(inv.invention.id, transfer.id, 'Contested ownership', rightsRole);
    const { data: dispInv } = await supabase.from('inventions').select('*').eq('id', inv.invention.id).maybeSingle();
    const { data: apprTransfer } = await supabase.from('transfers').select('*').eq('id', transfer.id).maybeSingle();
    let threw = false;
    try {
      await transitionTransfer(apprTransfer as any, dispInv as any, 'COMPLETED', adminRole);
    } catch {
      threw = true;
    }
    results.push({
      id: 9, name: 'Disputed transfer blocked', category,
      status: threw ? 'PASS' : 'FAIL',
      expected: 'Completion blocked when disputed', actual: threw ? 'Correctly blocked' : 'Was NOT blocked',
      timestamp: now(),
    });
  } catch (e) {
    results.push({ id: 9, name: 'Disputed transfer blocked', category, status: 'FAIL', expected: 'blocked', actual: 'Error', timestamp: now(), error: String(e) });
  }

  // Test 10: License creation and approval
  try {
    const inv = await registerInvention({
      title: `License Test ${Date.now()}`, description: 'd', inventor_name: 'Lic Inv', collaborators: [],
      organization: 'O', jurisdiction: 'US', claimed_owner: 'O', patent_application_number: '',
      notes: 'n', files: [], actorRole: role,
    });
    await transitionInvention(inv.invention, 'PENDING_APPROVAL', adminRole);
    await transitionInvention({ ...inv.invention, status: 'PENDING_APPROVAL' }, 'APPROVED', adminRole);
    const { data: apprInv } = await supabase.from('inventions').select('*').eq('id', inv.invention.id).maybeSingle();
    const license = await createLicense({
      invention_id: inv.invention.id, license_type: 'Non-exclusive', licensor: 'O', licensee: 'L',
      territory: 'US', start_date: '2024-01-01', expiry_date: '2025-01-01', notes: 'lic', actorRole: rightsRole,
    });
    const approved = await transitionLicense(license, apprInv as any, 'APPROVED', adminRole);
    results.push({
      id: 10, name: 'License creation and approval', category,
      status: approved.status === 'APPROVED' ? 'PASS' : 'FAIL',
      expected: 'License APPROVED', actual: approved.status, timestamp: now(),
    });
  } catch (e) {
    results.push({ id: 10, name: 'License creation and approval', category, status: 'FAIL', expected: 'APPROVED', actual: 'Error', timestamp: now(), error: String(e) });
  }

  // Test 11: Transaction timeout and reconciliation
  try {
    const tx = await submitSimulatedTransaction('TIMEOUT_TEST', { simulateTimeout: true });
    const reconciled = await reconcileTransaction(tx.transaction_id, tx.mode);
    results.push({
      id: 11, name: 'Transaction timeout and reconciliation', category,
      status: tx.status === 'PENDING' && reconciled.status === 'CONFIRMED' ? 'PASS' : 'FAIL',
      expected: 'PENDING then reconciled to CONFIRMED',
      actual: `${tx.status} -> ${reconciled.status}`,
      timestamp: now(),
    });
  } catch (e) {
    results.push({ id: 11, name: 'Transaction timeout and reconciliation', category, status: 'FAIL', expected: 'reconciled', actual: 'Error', timestamp: now(), error: String(e) });
  }

  // Test 12: Audit-history consistency
  try {
    const inv = await registerInvention({
      title: `Audit Test ${Date.now()}`, description: 'd', inventor_name: 'Aud Inv', collaborators: [],
      organization: 'O', jurisdiction: 'US', claimed_owner: 'O', patent_application_number: '',
      notes: 'n', files: [], actorRole: role,
    });
    const { data: events } = await supabase
      .from('audit_events')
      .select('*')
      .eq('invention_id', inv.invention.id)
      .order('timestamp', { ascending: true });
    const hasRegister = (events ?? []).some((e: any) => e.action === 'REGISTER_INVENTION');
    const allHaveTxId = (events ?? []).every((e: any) => !!e.transaction_id && !!e.transaction_mode);
    results.push({
      id: 12, name: 'Audit-history consistency', category,
      status: hasRegister && allHaveTxId ? 'PASS' : 'FAIL',
      expected: 'REGISTER_INVENTION event present, all events have tx id + mode',
      actual: `${events?.length ?? 0} events, register=${hasRegister}, allHaveTx=${allHaveTxId}`,
      timestamp: now(),
    });
  } catch (e) {
    results.push({ id: 12, name: 'Audit-history consistency', category, status: 'FAIL', expected: 'consistent', actual: 'Error', timestamp: now(), error: String(e) });
  }

  return results;
}
