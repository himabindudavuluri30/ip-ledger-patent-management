import { supabase } from './supabase';
import type { License, Transfer, LicenseStatus, TransferStatus, Role } from './supabase';
import { logAudit, canCompleteLicense, canCompleteTransfer } from './audit';
import { sha256OfFile, sha256OfText } from './crypto';
import type { Invention } from './supabase';

export interface CreateLicenseInput {
  invention_id: string;
  license_type: string;
  licensor: string;
  licensee: string;
  territory: string;
  start_date: string;
  expiry_date: string;
  notes: string;
  agreementFile?: File | null;
  actorRole: Role;
}

export async function createLicense(input: CreateLicenseInput): Promise<License> {
  let agreementHash: string | null = null;
  if (input.agreementFile) {
    agreementHash = await sha256OfFile(input.agreementFile);
  } else if (input.notes) {
    agreementHash = await sha256OfText(input.notes);
  }

  const { data, error } = await supabase
    .from('licenses')
    .insert({
      invention_id: input.invention_id,
      license_type: input.license_type || null,
      licensor: input.licensor || null,
      licensee: input.licensee || null,
      territory: input.territory || null,
      start_date: input.start_date || null,
      expiry_date: input.expiry_date || null,
      agreement_hash: agreementHash,
      status: 'REQUESTED',
      notes: input.notes || null,
    })
    .select()
    .maybeSingle();

  if (error || !data) throw new Error(`Database failure: ${error?.message ?? 'unknown'}`);

  const license = data as License;
  await logAudit({
    invention_id: input.invention_id,
    license_id: license.id,
    actor_role: input.actorRole,
    action: 'CREATE_LICENSE_REQUEST',
    previous_state: null,
    new_state: 'REQUESTED',
    details: `License request created (${input.license_type}) for ${input.licensee}.`,
  });
  return license;
}

export async function transitionLicense(
  license: License,
  invention: Invention,
  newStatus: LicenseStatus,
  actorRole: Role
): Promise<License> {
  if (
    (newStatus === 'APPROVED' || newStatus === 'REJECTED' || newStatus === 'TERMINATED') &&
    !['Institution/IP Administrator', 'Auditor', 'Rights Holder'].includes(actorRole)
  ) {
    throw new Error(`Unauthorized: role ${actorRole} cannot change license status to ${newStatus}.`);
  }

  if (newStatus === 'ACTIVE' && !canCompleteLicense(license.status, invention.status)) {
    throw new Error('Cannot activate license: invention is disputed or license not approved.');
  }

  const { data, error } = await supabase
    .from('licenses')
    .update({ status: newStatus, updated_at: new Date().toISOString() })
    .eq('id', license.id)
    .select()
    .maybeSingle();

  if (error || !data) throw new Error(`Database failure: ${error?.message ?? 'unknown'}`);

  const updated = data as License;
  await logAudit({
    invention_id: license.invention_id,
    license_id: license.id,
    actor_role: actorRole,
    action: `LICENSE_${newStatus}`,
    previous_state: license.status,
    new_state: newStatus,
    details: `License transitioned to ${newStatus}.`,
  });
  return updated;
}

export interface CreateTransferInput {
  invention_id: string;
  current_holder: string;
  proposed_recipient: string;
  notes: string;
  agreementFile?: File | null;
  actorRole: Role;
}

export async function createTransfer(input: CreateTransferInput): Promise<Transfer> {
  let agreementHash: string | null = null;
  if (input.agreementFile) {
    agreementHash = await sha256OfFile(input.agreementFile);
  } else if (input.notes) {
    agreementHash = await sha256OfText(input.notes);
  }

  const { data, error } = await supabase
    .from('transfers')
    .insert({
      invention_id: input.invention_id,
      current_holder: input.current_holder || null,
      proposed_recipient: input.proposed_recipient || null,
      agreement_hash: agreementHash,
      status: 'REQUESTED',
      notes: input.notes || null,
    })
    .select()
    .maybeSingle();

  if (error || !data) throw new Error(`Database failure: ${error?.message ?? 'unknown'}`);

  const transfer = data as Transfer;
  await logAudit({
    invention_id: input.invention_id,
    transfer_id: transfer.id,
    actor_role: input.actorRole,
    action: 'CREATE_TRANSFER_REQUEST',
    previous_state: null,
    new_state: 'REQUESTED',
    details: `Transfer request from ${input.current_holder} to ${input.proposed_recipient}.`,
  });
  return transfer;
}

export async function transitionTransfer(
  transfer: Transfer,
  invention: Invention,
  newStatus: TransferStatus,
  actorRole: Role
): Promise<Transfer> {
  if (
    (newStatus === 'APPROVED' || newStatus === 'REJECTED') &&
    !['Institution/IP Administrator', 'Auditor', 'Rights Holder'].includes(actorRole)
  ) {
    throw new Error(`Unauthorized: role ${actorRole} cannot ${newStatus.toLowerCase()} transfers.`);
  }

  if (newStatus === 'COMPLETED' && !canCompleteTransfer(transfer.status, invention.status)) {
    throw new Error(
      'Cannot complete transfer: transfer must be APPROVED and invention must not be DISPUTED.'
    );
  }

  const { data, error } = await supabase
    .from('transfers')
    .update({ status: newStatus, updated_at: new Date().toISOString() })
    .eq('id', transfer.id)
    .select()
    .maybeSingle();

  if (error || !data) throw new Error(`Database failure: ${error?.message ?? 'unknown'}`);

  const updated = data as Transfer;
  await logAudit({
    invention_id: transfer.invention_id,
    transfer_id: transfer.id,
    actor_role: actorRole,
    action: `TRANSFER_${newStatus}`,
    previous_state: transfer.status,
    new_state: newStatus,
    details: `Transfer transitioned to ${newStatus}.`,
  });
  return updated;
}

export async function raiseDispute(
  inventionId: string,
  transferId: string | null,
  reason: string,
  actorRole: Role
) {
  const { data, error } = await supabase
    .from('disputes')
    .insert({
      invention_id: inventionId,
      transfer_id: transferId,
      raised_by_role: actorRole,
      reason,
      status: 'OPEN',
    })
    .select()
    .maybeSingle();
  if (error || !data) throw new Error(`Database failure: ${error?.message ?? 'unknown'}`);

  // Mark invention as DISPUTED
  await supabase
    .from('inventions')
    .update({ status: 'DISPUTED', updated_at: new Date().toISOString() })
    .eq('id', inventionId);

  await logAudit({
    invention_id: inventionId,
    transfer_id: transferId,
    actor_role: actorRole,
    action: 'RAISE_DISPUTE',
    previous_state: null,
    new_state: 'DISPUTED',
    details: `Dispute raised: ${reason}`,
  });
  return data;
}
