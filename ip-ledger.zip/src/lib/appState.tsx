import { createContext, useContext, useState, useEffect, useCallback, type ReactNode } from 'react';
import type { Role } from './supabase';
import { getMode, setMode, isFabricConnected } from './blockchain';

interface ToastState {
  id: number;
  type: 'success' | 'error' | 'info';
  message: string;
}

interface AppState {
  role: Role;
  setRole: (r: Role) => void;
  mode: 'SIMULATED' | 'HYPERLEDGER_FABRIC';
  setAppMode: (m: 'SIMULATED' | 'HYPERLEDGER_FABRIC') => void;
  refreshMode: () => void;
  toast: ToastState | null;
  showToast: (type: 'success' | 'error' | 'info', message: string) => void;
  clearToast: () => void;
}

const AppContext = createContext<AppState | null>(null);

export function AppProvider({ children }: { children: ReactNode }) {
  const [role, setRoleState] = useState<Role>(() => {
    try {
      return (localStorage.getItem('ip_ledger_role') as Role) || 'Inventor';
    } catch {
      return 'Inventor';
    }
  });
  const [mode, setModeState] = useState<'SIMULATED' | 'HYPERLEDGER_FABRIC'>(() => getMode());
  const [toast, setToast] = useState<ToastState | null>(null);

  const setRole = (r: Role) => {
    localStorage.setItem('ip_ledger_role', r);
    setRoleState(r);
  };

  const setAppMode = (m: 'SIMULATED' | 'HYPERLEDGER_FABRIC') => {
    setMode(m);
    setModeState(m);
  };

  const refreshMode = useCallback(() => setModeState(getMode()), []);

  const showToast = useCallback((type: 'success' | 'error' | 'info', message: string) => {
    const id = Date.now() + Math.random();
    setToast({ id, type, message });
    setTimeout(() => {
      setToast((s) => (s?.id === id ? null : s));
    }, 4000);
  }, []);

  const clearToast = useCallback(() => setToast(null), []);

  useEffect(() => { refreshMode(); }, [refreshMode]);

  return (
    <AppContext.Provider value={{ role, setRole, mode, setAppMode, refreshMode, toast, showToast, clearToast }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp<T = AppState>(selector?: (s: AppState) => T): T {
  const ctx = useContext(AppContext);
  if (!ctx) {
    // Defensive fallback: should never happen because AppProvider wraps the whole
    // tree in main.tsx. Returning a safe default instead of throwing keeps a
    // transient missing context from blanking the page in production.
    const fallback = {} as AppState;
    return selector ? selector(fallback) : (fallback as unknown as T);
  }
  return selector ? selector(ctx) : (ctx as unknown as T);
}

export function useToast() {
  const showToast = useApp((s) => s.showToast);
  return useCallback(
    (type: 'success' | 'error' | 'info', message: string) => showToast(type, message),
    [showToast]
  );
}

export { isFabricConnected };
