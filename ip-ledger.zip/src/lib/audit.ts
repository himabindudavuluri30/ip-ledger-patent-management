import { supabase } from './supabase';
import type {
  AuditEvent,
  InventionStatus,
  LicenseStatus,
  TransferStatus,
  TransactionMode,
  TransactionStatus,
} from './supabase';
import {
  generateEventId,
  submitSimulatedTransaction,
  reconcileTransaction,
  getMode,
} from './blockchain';

export interface AuditLogInput {
  invention_id?: string | null;
  license_id?: string | null;
  transfer_id?: string | null;
  actor_role: string;
  action: string;
  previous_state?: string | null;
  new_state?: string | null;
  details?: string | null;
}

// Append an audit event. Records the transaction mode and status from the
// blockchain layer. This is application-level append-only history — NOT a
// claim that ordinary DB rows are immutable blockchain records.
export async function logAudit(
  input: AuditLogInput,
  options: { simulateTimeout?: boolean; simulateFailure?: boolean } = {}
): Promise<AuditEvent | null> {
  const mode: TransactionMode = getMode();
  const tx = await submitSimulatedTransaction(input.action, options);

  let finalTx = tx;
  if (tx.status === 'PENDING') {
    // Reconcile after timeout.
    finalTx = await reconcileTransaction(tx.transaction_id, mode);
  }

  const eventId = generateEventId();
  const { data, error } = await supabase
    .from('audit_events')
    .insert({
      event_id: eventId,
      invention_id: input.invention_id ?? null,
      license_id: input.license_id ?? null,
      transfer_id: input.transfer_id ?? null,
      actor_role: input.actor_role,
      action: input.action,
      previous_state: input.previous_state ?? null,
      new_state: input.new_state ?? null,
      transaction_id: finalTx.transaction_id,
      transaction_mode: finalTx.mode,
      transaction_status: finalTx.status as TransactionStatus,
      details: input.details ?? null,
    })
    .select()
    .maybeSingle();

  if (error) {
    console.error('Failed to log audit event:', error);
    return null;
  }
  return data as AuditEvent;
}

// Invention status helpers
export const INVENTION_STATUS_FLOW: Record<InventionStatus, InventionStatus[]> = {
  PROPOSED: ['PENDING_APPROVAL'],
  PENDING_APPROVAL: ['APPROVED', 'REJECTED', 'DISPUTED'],
  APPROVED: ['RECORDED', 'DISPUTED'],
  RECORDED: ['COMPLETED', 'DISPUTED'],
  COMPLETED: ['DISPUTED'],
  REJECTED: [],
  DISPUTED: ['RESOLVED' as InventionStatus],
};

export function canApprove(status: InventionStatus): boolean {
  return status === 'PENDING_APPROVAL';
}

export function canReject(status: InventionStatus): boolean {
  return status === 'PENDING_APPROVAL';
}

export function canDispute(status: InventionStatus): boolean {
  return ['PENDING_APPROVAL', 'APPROVED', 'RECORDED', 'COMPLETED'].includes(status);
}

// Roles that can approve/reject (authorized approvers).
export const APPROVER_ROLES = ['Institution/IP Administrator', 'Auditor'];
export const DISPUTE_ROLES = ['Rights Holder', 'Institution/IP Administrator', 'Auditor', 'Licensee'];

export function canRoleApprove(role: string): boolean {
  return APPROVER_ROLES.includes(role);
}

export function canRoleDispute(role: string): boolean {
  return DISPUTE_ROLES.includes(role);
}

// A disputed record cannot complete a transfer requiring uncontested authorization.
export function isDisputed(inventionStatus: InventionStatus): boolean {
  return inventionStatus === 'DISPUTED';
}

export function canCompleteTransfer(
  transferStatus: TransferStatus,
  inventionStatus: InventionStatus
): boolean {
  if (transferStatus !== 'APPROVED') return false;
  if (isDisputed(inventionStatus)) return false;
  return true;
}

export function canCompleteLicense(
  licenseStatus: LicenseStatus,
  inventionStatus: InventionStatus
): boolean {
  if (licenseStatus !== 'APPROVED') return false;
  if (isDisputed(inventionStatus)) return false;
  return true;
}
