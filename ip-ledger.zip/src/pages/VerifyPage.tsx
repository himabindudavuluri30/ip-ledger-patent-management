import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import type { Invention, DocumentRecord } from '@/lib/supabase';
import { sha256OfFile } from '@/lib/crypto';
import { Card, Button, Spinner, EmptyState, Select } from '@/components/ui';
import { ShieldCheck, AlertTriangle, CheckCircle2, XCircle, HelpCircle, FileText, Hash } from 'lucide-react';

type VerifyResult =
  | { kind: 'MATCH'; recordedHash: string; candidateHash: string; version: number; timestamp: string }
  | { kind: 'MISMATCH'; recordedHash: string; candidateHash: string; version: number; timestamp: string }
  | { kind: 'UNAVAILABLE'; reason: string; timestamp: string };

export function VerifyPage() {
  const [inventions, setInventions] = useState<Invention[]>([]);
  const [docsMap, setDocsMap] = useState<Record<string, DocumentRecord[]>>({});
  const [selectedInv, setSelectedInv] = useState<string>('');
  const [selectedDocId, setSelectedDocId] = useState<string>('');
  const [candidateFile, setCandidateFile] = useState<File | null>(null);
  const [result, setResult] = useState<VerifyResult | null>(null);
  const [busy, setBusy] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        const { data } = await supabase.from('inventions').select('*').order('created_at', { ascending: false });
        const invs = (data as Invention[]) ?? [];
        setInventions(invs);
        const map: Record<string, DocumentRecord[]> = {};
        for (const inv of invs) {
          const { data: docs } = await supabase.from('documents').select('*').eq('invention_id', inv.id).order('version', { ascending: true });
          map[inv.id] = (docs as DocumentRecord[]) ?? [];
        }
        setDocsMap(map);
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  const docs = selectedInv ? docsMap[selectedInv] ?? [] : [];
  const selectedDoc = docs.find((d) => d.id === selectedDocId);

  const verify = async () => {
    if (!selectedDoc) {
      setResult({ kind: 'UNAVAILABLE', reason: 'No reference document selected.', timestamp: new Date().toISOString() });
      return;
    }
    if (!candidateFile) {
      setResult({ kind: 'UNAVAILABLE', reason: 'No candidate file uploaded.', timestamp: new Date().toISOString() });
      return;
    }
    setBusy(true);
    try {
      const candidateHash = await sha256OfFile(candidateFile);
      const timestamp = new Date().toISOString();
      if (!selectedDoc.sha256_hash) {
        setResult({ kind: 'UNAVAILABLE', reason: 'Reference hash missing.', timestamp });
      } else if (candidateHash === selectedDoc.sha256_hash) {
        setResult({ kind: 'MATCH', recordedHash: selectedDoc.sha256_hash, candidateHash, version: selectedDoc.version, timestamp });
      } else {
        setResult({ kind: 'MISMATCH', recordedHash: selectedDoc.sha256_hash, candidateHash, version: selectedDoc.version, timestamp });
      }
    } catch (e) {
      setResult({ kind: 'UNAVAILABLE', reason: e instanceof Error ? e.message : String(e), timestamp: new Date().toISOString() });
    } finally {
      setBusy(false);
    }
  };

  if (loading) {
    return <div className="flex justify-center py-12"><Spinner className="h-6 w-6" /></div>;
  }

  return (
    <div className="space-y-6">
      <Card className="p-5">
        <div className="flex items-center gap-2 mb-4">
          <ShieldCheck className="text-navy-700" size={20} />
          <h3 className="text-base font-semibold text-navy-800">Document Integrity Verification</h3>
        </div>
        <p className="text-sm text-slate-600 mb-4">
          Select a previously registered document, then upload a candidate file. We compute the
          candidate's SHA-256 hash and compare it with the recorded hash.
        </p>

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <Select label="Select Invention" value={selectedInv} onChange={(e) => { setSelectedInv(e.target.value); setSelectedDocId(''); setResult(null); }}>
            <option value="">Choose...</option>
            {inventions.map((i) => (
              <option key={i.id} value={i.id}>{i.internal_id} — {i.title}</option>
            ))}
          </Select>

          <Select label="Select Document" value={selectedDocId} onChange={(e) => { setSelectedDocId(e.target.value); setResult(null); }} disabled={!selectedInv}>
            <option value="">Choose...</option>
            {docs.map((d) => (
              <option key={d.id} value={d.id}>v{d.version} — {d.filename}</option>
            ))}
          </Select>
        </div>

        {selectedDoc && (
          <div className="mt-4 rounded-lg border border-slate-200 bg-slate-50 p-3">
            <div className="flex items-center gap-2 text-sm font-medium text-navy-700">
              <FileText size={14} /> {selectedDoc.filename}
            </div>
            <p className="mt-1.5 font-mono text-xs text-slate-600 break-all">
              <Hash size={11} className="inline mr-1" />{selectedDoc.sha256_hash}
            </p>
            <p className="mt-1 text-xs text-slate-500">Version {selectedDoc.version} • Uploaded {new Date(selectedDoc.uploaded_at).toLocaleString()}</p>
          </div>
        )}

        <div className="mt-4">
          <label className="block text-sm font-medium text-slate-700 mb-1">Upload candidate file for verification</label>
          <input
            type="file"
            onChange={(e) => { setCandidateFile(e.target.files?.[0] ?? null); setResult(null); }}
            className="block w-full text-sm text-slate-500 file:mr-3 file:rounded-lg file:border-0 file:bg-navy-50 file:px-4 file:py-2 file:text-sm file:font-medium file:text-navy-700 hover:file:bg-navy-100"
          />
          {candidateFile && (
            <p className="mt-1 text-xs text-slate-600">{candidateFile.name} ({(candidateFile.size / 1024).toFixed(1)} KB)</p>
          )}
        </div>

        <div className="mt-4">
          <Button onClick={verify} disabled={busy || !selectedDoc || !candidateFile}>
            {busy ? <Spinner /> : null}
            {busy ? 'Verifying...' : 'Verify Integrity'}
          </Button>
        </div>
      </Card>

      {result && (
        <Card className="p-5">
          <h3 className="text-base font-semibold text-navy-800 mb-3">Verification Result</h3>
          <div className={`rounded-lg border p-4 ${
            result.kind === 'MATCH'
              ? 'border-emerald-200 bg-emerald-50'
              : result.kind === 'MISMATCH'
              ? 'border-rose-200 bg-rose-50'
              : 'border-slate-200 bg-slate-50'
          }`}>
            <div className="flex items-center gap-2">
              {result.kind === 'MATCH' ? (
                <><CheckCircle2 className="text-emerald-600" size={22} /><span className="text-lg font-bold text-emerald-700">MATCH</span></>
              ) : result.kind === 'MISMATCH' ? (
                <><XCircle className="text-rose-600" size={22} /><span className="text-lg font-bold text-rose-700">MISMATCH</span></>
              ) : (
                <><HelpCircle className="text-slate-600" size={22} /><span className="text-lg font-bold text-slate-700">UNAVAILABLE</span></>
              )}
            </div>
            <p className="mt-2 text-sm text-slate-700">
              {result.kind === 'MATCH'
                ? 'The file content matches the recorded digest.'
                : result.kind === 'MISMATCH'
                ? 'The file content differs from the recorded digest.'
                : `The reference hash or document cannot be retrieved: ${result.reason}`}
            </p>
            <p className="mt-2 text-xs text-slate-500">Verification timestamp: {new Date(result.timestamp).toLocaleString()}</p>
          </div>

          {(result.kind === 'MATCH' || result.kind === 'MISMATCH') && (
            <div className="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-2">
              <div className="rounded-lg border border-slate-200 p-3">
                <p className="text-xs font-medium text-slate-500 mb-1">Recorded Hash (v{result.version})</p>
                <p className="font-mono text-xs text-navy-700 break-all">{result.recordedHash}</p>
              </div>
              <div className="rounded-lg border border-slate-200 p-3">
                <p className="text-xs font-medium text-slate-500 mb-1">Candidate Hash</p>
                <p className="font-mono text-xs text-navy-700 break-all">{result.candidateHash}</p>
              </div>
            </div>
          )}

          <div className="mt-4 rounded-lg border border-amber-200 bg-amber-50 px-3 py-2 text-xs text-amber-800">
            <strong>Important:</strong> Matching hashes do not prove legal ownership, inventorship,
            authenticity of the original claims, or patent grant. They only confirm that the file
            content is identical to the originally recorded digest.
          </div>
        </Card>
      )}

      {inventions.length === 0 && (
        <EmptyState
          icon={<AlertTriangle size={40} />}
          title="No inventions to verify"
          description="Register an invention or load sample data first."
        />
      )}
    </div>
  );
}
