import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import type { Invention, AuditEvent } from '@/lib/supabase';
import { Card, Badge, Spinner, EmptyState } from '@/components/ui';
import { useApp } from '@/lib/appState';
import { FileText, Clock, CheckCircle2, AlertTriangle, FileCheck2, Scale } from 'lucide-react';

interface Stats {
  total: number;
  pending: number;
  confirmedTx: number;
  activeLicenses: number;
  disputed: number;
}

export function DashboardPage() {
  const mode = useApp((s) => s.mode);
  const [stats, setStats] = useState<Stats | null>(null);
  const [recent, setRecent] = useState<AuditEvent[]>([]);
  const [statusDist, setStatusDist] = useState<{ status: string; count: number }[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    (async () => {
      try {
        const [
          { count: total, error: e1 },
          { count: pending, error: e2 },
          { count: confirmedTx, error: e3 },
          { count: activeLicenses, error: e4 },
          { count: disputed, error: e5 },
          { data: recentData, error: e6 },
          { data: statusData, error: e7 },
        ] = await Promise.all([
          supabase.from('inventions').select('*', { count: 'exact', head: true }),
          supabase.from('inventions').select('*', { count: 'exact', head: true }).eq('status', 'PENDING_APPROVAL'),
          supabase.from('audit_events').select('*', { count: 'exact', head: true }).eq('transaction_status', 'CONFIRMED'),
          supabase.from('licenses').select('*', { count: 'exact', head: true }).in('status', ['ACTIVE', 'APPROVED']),
          supabase.from('inventions').select('*', { count: 'exact', head: true }).eq('status', 'DISPUTED'),
          supabase.from('audit_events').select('*').order('timestamp', { ascending: false }).limit(8),
          supabase.from('inventions').select('status'),
        ]);

        if (e1 || e2 || e3 || e4 || e5 || e6 || e7) {
          throw new Error(e1?.message || e6?.message || 'Failed to load stats');
        }

        setStats({
          total: total ?? 0,
          pending: pending ?? 0,
          confirmedTx: confirmedTx ?? 0,
          activeLicenses: activeLicenses ?? 0,
          disputed: disputed ?? 0,
        });
        setRecent((recentData as AuditEvent[]) ?? []);

        // Compute status distribution from actual records
        const dist: Record<string, number> = {};
        for (const row of (statusData as Pick<Invention, 'status'>[]) ?? []) {
          dist[row.status] = (dist[row.status] ?? 0) + 1;
        }
        setStatusDist(
          Object.entries(dist).map(([status, count]) => ({ status, count }))
        );
      } catch (e) {
        setError(e instanceof Error ? e.message : String(e));
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <Spinner className="h-6 w-6" />
      </div>
    );
  }

  if (error) {
    return (
      <EmptyState
        icon={<AlertTriangle size={40} />}
        title="Failed to load dashboard"
        description={error}
      />
    );
  }

  const cards = [
    { label: 'Total Invention Records', value: stats!.total, icon: FileText, tone: 'navy' as const },
    { label: 'Pending Approvals', value: stats!.pending, icon: Clock, tone: 'warning' as const },
    { label: 'Confirmed Ledger Transactions', value: stats!.confirmedTx, icon: CheckCircle2, tone: 'success' as const },
    { label: 'Active License Records', value: stats!.activeLicenses, icon: FileCheck2, tone: 'info' as const },
    { label: 'Disputed Records', value: stats!.disputed, icon: Scale, tone: 'error' as const },
  ];

  const maxCount = Math.max(...statusDist.map((d) => d.count), 1);

  return (
    <div className="space-y-6">
      {/* Mode indicator */}
      <div className={`rounded-lg border px-4 py-3 text-sm ${
        mode === 'HYPERLEDGER_FABRIC'
          ? 'border-emerald-200 bg-emerald-50 text-emerald-800'
          : 'border-amber-200 bg-amber-50 text-amber-800'
      }`}>
        {mode === 'HYPERLEDGER_FABRIC' ? (
          <span><strong>HYPERLEDGER FABRIC CONNECTED</strong> — Real Fabric network verified.</span>
        ) : (
          <span><strong>SIMULATION MODE</strong> — Hyperledger Fabric is not connected. You are using simulation mode with mock blockchain records.</span>
        )}
      </div>

      {/* Stat cards */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-5">
        {cards.map((c) => {
          const Icon = c.icon;
          const toneClasses = {
            navy: 'bg-navy-50 text-navy-700 border-navy-200',
            warning: 'bg-amber-50 text-amber-700 border-amber-200',
            success: 'bg-emerald-50 text-emerald-700 border-emerald-200',
            info: 'bg-sky-50 text-sky-700 border-sky-200',
            error: 'bg-rose-50 text-rose-700 border-rose-200',
          };
          return (
            <Card key={c.label} className="p-4">
              <div className="flex items-center justify-between">
                <div className={`flex h-10 w-10 items-center justify-center rounded-lg border ${toneClasses[c.tone]}`}>
                  <Icon size={18} />
                </div>
                <span className="text-2xl font-bold text-navy-800">{c.value}</span>
              </div>
              <p className="mt-2 text-xs font-medium text-slate-600">{c.label}</p>
            </Card>
          );
        })}
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        {/* Status distribution */}
        <Card className="p-5 lg:col-span-1">
          <h3 className="text-sm font-semibold text-navy-800 mb-4">Invention Status Distribution</h3>
          {statusDist.length === 0 ? (
            <p className="text-xs text-slate-500">No records yet.</p>
          ) : (
            <div className="space-y-2.5">
              {statusDist.map((d) => (
                <div key={d.status}>
                  <div className="flex items-center justify-between text-xs mb-1">
                    <span className="font-medium text-slate-700">{d.status}</span>
                    <span className="text-slate-500">{d.count}</span>
                  </div>
                  <div className="h-2 w-full overflow-hidden rounded-full bg-slate-100">
                    <div
                      className="h-full rounded-full bg-navy-600"
                      style={{ width: `${(d.count / maxCount) * 100}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          )}
        </Card>

        {/* Recent activity */}
        <Card className="p-5 lg:col-span-2">
          <h3 className="text-sm font-semibold text-navy-800 mb-4">Recent Activity</h3>
          {recent.length === 0 ? (
            <EmptyState title="No activity yet" description="Load sample data or register an invention to see activity." />
          ) : (
            <div className="space-y-2">
              {recent.map((e) => (
                <div key={e.id} className="flex items-start gap-3 rounded-lg border border-slate-100 p-3">
                  <div className={`mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-full ${
                    e.transaction_status === 'CONFIRMED'
                      ? 'bg-emerald-100 text-emerald-700'
                      : e.transaction_status === 'FAILED'
                      ? 'bg-rose-100 text-rose-700'
                      : 'bg-amber-100 text-amber-700'
                  }`}>
                    <CheckCircle2 size={14} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-sm font-medium text-navy-800">{e.action}</span>
                      <Badge tone={e.transaction_mode === 'HYPERLEDGER_FABRIC' ? 'success' : 'warning'}>
                        {e.transaction_mode === 'SIMULATED' ? 'SIMULATED' : 'FABRIC'}
                      </Badge>
                    </div>
                    <p className="text-xs text-slate-500 mt-0.5 truncate">{e.details}</p>
                    <p className="text-[11px] text-slate-400 mt-0.5">
                      {new Date(e.timestamp).toLocaleString()} • tx: {e.transaction_id?.slice(0, 16)}…
                    </p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </Card>
      </div>

      {/* Recent transactions table */}
      <Card className="p-5">
        <h3 className="text-sm font-semibold text-navy-800 mb-4">Recent Transaction Identifiers</h3>
        {recent.length === 0 ? (
          <p className="text-xs text-slate-500">No transactions yet.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-slate-200 text-left text-xs uppercase text-slate-500">
                  <th className="pb-2 pr-4 font-medium">Transaction ID</th>
                  <th className="pb-2 pr-4 font-medium">Mode</th>
                  <th className="pb-2 pr-4 font-medium">Status</th>
                  <th className="pb-2 pr-4 font-medium">Action</th>
                  <th className="pb-2 font-medium">Timestamp</th>
                </tr>
              </thead>
              <tbody>
                {recent.map((e) => (
                  <tr key={e.id} className="border-b border-slate-100 last:border-0">
                    <td className="py-2 pr-4 font-mono text-xs text-navy-700">{e.transaction_id}</td>
                    <td className="py-2 pr-4">
                      <Badge tone={e.transaction_mode === 'SIMULATED' ? 'warning' : 'success'}>
                        {e.transaction_mode}
                      </Badge>
                    </td>
                    <td className="py-2 pr-4">
                      <Badge tone={e.transaction_status === 'CONFIRMED' ? 'success' : e.transaction_status === 'FAILED' ? 'error' : 'warning'}>
                        {e.transaction_status}
                      </Badge>
                    </td>
                    <td className="py-2 pr-4 text-slate-700">{e.action}</td>
                    <td className="py-2 text-xs text-slate-500">{new Date(e.timestamp).toLocaleString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>
    </div>
  );
}
