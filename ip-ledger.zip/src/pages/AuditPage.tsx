import { useEffect, useState, useCallback } from 'react';
import { supabase } from '@/lib/supabase';
import type { AuditEvent, Invention } from '@/lib/supabase';
import { Card, Badge, Button, Spinner, EmptyState } from '@/components/ui';
import { History, Search, Download } from 'lucide-react';

export function AuditPage() {
  const [events, setEvents] = useState<AuditEvent[]>([]);
  const [invMap, setInvMap] = useState<Record<string, Invention>>({});
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [actionFilter, setActionFilter] = useState('ALL');
  const [modeFilter, setModeFilter] = useState('ALL');

  const fetch = useCallback(async () => {
    setLoading(true);
    try {
      const [{ data: evData }, { data: invData }] = await Promise.all([
        supabase.from('audit_events').select('*').order('timestamp', { ascending: false }).limit(500),
        supabase.from('inventions').select('*'),
      ]);
      setEvents((evData as AuditEvent[]) ?? []);
      setInvMap(Object.fromEntries(((invData as Invention[]) ?? []).map((i) => [i.id, i])));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { fetch(); }, [fetch]);

  const actions = Array.from(new Set(events.map((e) => e.action))).sort();

  const filtered = events.filter((e) => {
    const s = search.toLowerCase();
    const matchesSearch =
      !s ||
      e.event_id.toLowerCase().includes(s) ||
      e.transaction_id?.toLowerCase().includes(s) ||
      e.action.toLowerCase().includes(s) ||
      e.actor_role?.toLowerCase().includes(s) ||
      (invMap[e.invention_id ?? '']?.internal_id.toLowerCase().includes(s) ?? false);
    const matchesAction = actionFilter === 'ALL' || e.action === actionFilter;
    const matchesMode = modeFilter === 'ALL' || e.transaction_mode === modeFilter;
    return matchesSearch && matchesAction && matchesMode;
  });

  const exportCsv = () => {
    const rows = [
      ['event_id', 'invention_id', 'action', 'actor_role', 'previous_state', 'new_state', 'transaction_id', 'transaction_mode', 'transaction_status', 'timestamp', 'details'],
      ...filtered.map((e) => [
        e.event_id,
        invMap[e.invention_id ?? '']?.internal_id ?? '',
        e.action,
        e.actor_role ?? '',
        e.previous_state ?? '',
        e.new_state ?? '',
        e.transaction_id ?? '',
        e.transaction_mode,
        e.transaction_status,
        new Date(e.timestamp).toISOString(),
        (e.details ?? '').replace(/"/g, '""'),
      ]),
    ];
    const csv = rows.map((r) => r.map((c) => `"${c}"`).join(',')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'ip-ledger-audit-history.csv';
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex flex-1 flex-col gap-2 sm:flex-row">
          <div className="relative flex-1 max-w-xs">
            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Search event ID, tx, action..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full rounded-lg border border-slate-300 pl-9 pr-3 py-2 text-sm outline-none focus:border-navy-500"
            />
          </div>
          <select value={actionFilter} onChange={(e) => setActionFilter(e.target.value)} className="rounded-lg border border-slate-300 px-3 py-2 text-sm bg-white">
            <option value="ALL">All actions</option>
            {actions.map((a) => <option key={a} value={a}>{a}</option>)}
          </select>
          <select value={modeFilter} onChange={(e) => setModeFilter(e.target.value)} className="rounded-lg border border-slate-300 px-3 py-2 text-sm bg-white">
            <option value="ALL">All modes</option>
            <option value="SIMULATED">SIMULATED</option>
            <option value="HYPERLEDGER_FABRIC">HYPERLEDGER FABRIC</option>
          </select>
        </div>
        <Button variant="outline" size="sm" onClick={exportCsv}><Download size={14} /> Export CSV</Button>
      </div>

      <div className="rounded-lg border border-slate-200 bg-slate-50 px-4 py-2.5 text-xs text-slate-600">
        These are application-level append-only event records. Ordinary database records are NOT
        immutable blockchain records. Transaction mode is shown for each event.
      </div>

      {loading ? (
        <div className="flex justify-center py-12"><Spinner className="h-6 w-6" /></div>
      ) : filtered.length === 0 ? (
        <EmptyState icon={<History size={40} />} title="No audit events" description="Activity will appear here as you use the application." />
      ) : (
        <Card className="overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-slate-50">
                <tr className="text-left text-xs uppercase text-slate-500">
                  <th className="px-3 py-3 font-medium">Event ID</th>
                  <th className="px-3 py-3 font-medium">Invention</th>
                  <th className="px-3 py-3 font-medium">Actor</th>
                  <th className="px-3 py-3 font-medium">Action</th>
                  <th className="px-3 py-3 font-medium">State</th>
                  <th className="px-3 py-3 font-medium">Tx ID</th>
                  <th className="px-3 py-3 font-medium">Mode</th>
                  <th className="px-3 py-3 font-medium">Status</th>
                  <th className="px-3 py-3 font-medium">Timestamp</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((e) => (
                  <tr key={e.id} className="border-t border-slate-100 hover:bg-slate-50">
                    <td className="px-3 py-2 font-mono text-[11px] text-navy-700">{e.event_id}</td>
                    <td className="px-3 py-2 font-mono text-xs text-navy-700">{e.invention_id ? invMap[e.invention_id]?.internal_id ?? '—' : '—'}</td>
                    <td className="px-3 py-2 text-xs text-slate-700">{e.actor_role ?? '—'}</td>
                    <td className="px-3 py-2 text-xs font-medium text-navy-800">{e.action}</td>
                    <td className="px-3 py-2 text-xs text-slate-600">
                      {e.previous_state ?? '—'} → {e.new_state ?? '—'}
                    </td>
                    <td className="px-3 py-2 font-mono text-[11px] text-slate-600">{e.transaction_id?.slice(0, 14) ?? '—'}…</td>
                    <td className="px-3 py-2">
                      <Badge tone={e.transaction_mode === 'SIMULATED' ? 'warning' : 'success'}>
                        {e.transaction_mode === 'SIMULATED' ? 'SIMULATED' : 'FABRIC'}
                      </Badge>
                    </td>
                    <td className="px-3 py-2">
                      <Badge tone={e.transaction_status === 'CONFIRMED' ? 'success' : e.transaction_status === 'FAILED' ? 'error' : e.transaction_status === 'PENDING' ? 'warning' : 'neutral'}>
                        {e.transaction_status}
                      </Badge>
                    </td>
                    <td className="px-3 py-2 text-xs text-slate-500">{new Date(e.timestamp).toLocaleString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      )}
    </div>
  );
}
