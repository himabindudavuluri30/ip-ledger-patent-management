import { useState } from 'react';
import { Card, Badge } from '@/components/ui';
import { useApp } from '@/lib/appState';
import { Settings as SettingsIcon, Link2, AlertTriangle, ShieldCheck, Server, Terminal, FileCode } from 'lucide-react';

export function SettingsPage() {
  const mode = useApp((s) => s.mode);
  const setAppMode = useApp((s) => s.setAppMode);
  const showToast = useApp((s) => s.showToast);
  const [showChaincode, setShowChaincode] = useState(false);
  const [showEnv, setShowEnv] = useState(false);
  const [showBackend, setShowBackend] = useState(false);

  return (
    <div className="space-y-6">
      {/* Mode selector */}
      <Card className="p-5">
        <div className="flex items-center gap-2 mb-3">
          <SettingsIcon className="text-navy-700" size={20} />
          <h3 className="text-base font-semibold text-navy-800">Transaction Mode</h3>
        </div>
        <p className="text-sm text-slate-600 mb-4">
          The application runs in two explicitly separated modes. Simulation mode works immediately
          without Hyperledger Fabric. Real Fabric mode is only enabled when the backend can verify a
          genuine committed transaction — a successful simulation must never activate it.
        </p>

        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          <button
            onClick={() => { setAppMode('SIMULATED'); showToast('info', 'Switched to SIMULATION MODE.'); }}
            className={`rounded-lg border p-4 text-left transition-colors ${
              mode === 'SIMULATED' ? 'border-amber-300 bg-amber-50' : 'border-slate-200 bg-white hover:bg-slate-50'
            }`}
          >
            <div className="flex items-center gap-2 mb-1">
              <AlertTriangle className="text-amber-600" size={18} />
              <span className="font-semibold text-navy-800">SIMULATION MODE</span>
              {mode === 'SIMULATED' && <Badge tone="warning">Active</Badge>}
            </div>
            <p className="text-xs text-slate-600">Mock blockchain records. Labeled SIMULATED. No Fabric installation required.</p>
          </button>

          <button
            onClick={() => {
              // Real Fabric mode requires a verified connection. In this hosted demo there is no
              // Fabric network, so we show the not-connected message and refuse to enable it.
              showToast('error', 'Hyperledger Fabric is not connected. You are using simulation mode.');
            }}
            className={`rounded-lg border p-4 text-left transition-colors ${
              mode === 'HYPERLEDGER_FABRIC' ? 'border-emerald-300 bg-emerald-50' : 'border-slate-200 bg-white hover:bg-slate-50'
            }`}
          >
            <div className="flex items-center gap-2 mb-1">
              <Link2 className="text-emerald-600" size={18} />
              <span className="font-semibold text-navy-800">HYPERLEDGER FABRIC</span>
              {mode === 'HYPERLEDGER_FABRIC' && <Badge tone="success">Active</Badge>}
            </div>
            <p className="text-xs text-slate-600">Requires a running Fabric network and verified connection. Not available in this hosted demo.</p>
          </button>
        </div>

        <div className={`mt-4 rounded-lg border px-4 py-3 text-sm ${
          mode === 'HYPERLEDGER_FABRIC'
            ? 'border-emerald-200 bg-emerald-50 text-emerald-800'
            : 'border-amber-200 bg-amber-50 text-amber-800'
        }`}>
          {mode === 'HYPERLEDGER_FABRIC' ? (
            <span className="flex items-center gap-2"><ShieldCheck size={16} /> HYPERLEDGER FABRIC CONNECTED — Real Fabric network verified.</span>
          ) : (
            <span className="flex items-center gap-2"><AlertTriangle size={16} /> Hyperledger Fabric is not connected. You are using simulation mode.</span>
          )}
        </div>
      </Card>

      {/* Fabric integration documentation */}
      <Card className="p-5">
        <div className="flex items-center gap-2 mb-3">
          <Server className="text-navy-700" size={20} />
          <h3 className="text-base font-semibold text-navy-800">Hyperledger Fabric Integration</h3>
        </div>
        <p className="text-sm text-slate-600 mb-4">
          The code below documents how to connect the application to a real Hyperledger Fabric
          network. In the hosted Bolt environment, a separate Node.js/Express backend and Docker
          are not available, so Fabric mode cannot be activated here — this is the documented
          alternative architecture for local deployment.
        </p>

        <div className="space-y-3">
          <button
            onClick={() => setShowChaincode(!showChaincode)}
            className="flex w-full items-center justify-between rounded-lg border border-slate-200 bg-slate-50 px-4 py-3 text-left text-sm font-medium text-navy-800 hover:bg-slate-100"
          >
            <span className="flex items-center gap-2"><FileCode size={16} /> Chaincode (Go) — required functions</span>
            <span className="text-xs text-slate-500">{showChaincode ? 'Hide' : 'Show'}</span>
          </button>
          {showChaincode && (
            <pre className="overflow-x-auto rounded-lg bg-navy-900 p-4 text-xs text-navy-50 font-mono leading-relaxed">{`// ipledger.go — Hyperledger Fabric chaincode (Fabric Gateway compatible)
package main

import (
  "encoding/json"
  "fmt"
  "crypto/sha256"
  "github.com/hyperledger/fabric-contract-api-go/contractapi"
)

type SmartContract struct { contractapi.Contract }

type Invention struct {
  ID            string \`json:"id"\`
  Title         string \`json:"title"\`
  Inventor      string \`json:"inventor"\`
  Organization  string \`json:"organization"\`
  Status        string \`json:"status"\`
  Owner         string \`json:"owner"\`
  DocHashes     []string \`json:"docHashes"\`
}

// registerInvention creates a new invention record on the ledger.
func (s *SmartContract) RegisterInvention(ctx contractapi.TransactionContextInterface,
    id, title, inventor, org, owner string) (*Invention, error) {
  existing, _ := ctx.GetStub().GetState(id)
  if existing != nil { return nil, fmt.Errorf("invention %s already exists", id) }
  inv := &Invention{ID: id, Title: title, Inventor: inventor, Organization: org, Owner: owner, Status: "PROPOSED"}
  bytes, _ := json.Marshal(inv)
  return inv, ctx.GetStub().PutState(id, bytes)
}

// addDocumentVersion attaches a new document hash to an invention.
func (s *SmartContract) AddDocumentVersion(ctx contractapi.TransactionContextInterface,
    id, docHash string) error {
  inv, err := s.readInvention(ctx, id); if err != nil { return err }
  inv.DocHashes = append(inv.DocHashes, docHash)
  bytes, _ := json.Marshal(inv)
  return ctx.GetStub().PutState(id, bytes)
}

// verifyDocumentHash checks whether a hash is recorded for an invention.
func (s *SmartContract) VerifyDocumentHash(ctx contractapi.TransactionContextInterface,
    id, candidateHash string) (bool, error) {
  inv, err := s.readInvention(ctx, id); if err != nil { return false, err }
  for _, h := range inv.DocHashes { if h == candidateHash { return true, nil } }
  return false, nil
}

// submitTransferRequest / approveTransfer / rejectTransfer / completeTransfer
// createLicenseRecord / approveLicense / recordDispute / getInventionHistory
// follow the same pattern: validate caller identity (ctx.GetClientIdentity()),
// mutate state, emit events via ctx.GetStub().SetEvent(...).

func (s *SmartContract) readInvention(ctx contractapi.TransactionContextInterface,
    id string) (*Invention, error) {
  bytes, err := ctx.GetStub().GetState(id)
  if err != nil { return nil, err }
  if bytes == nil { return nil, fmt.Errorf("invention %s not found", id) }
  inv := &Invention{}; err = json.Unmarshal(bytes, inv); return inv, err
}

func main() {
  cc, _ := contractapi.NewChaincode(&SmartContract{})
  cc.Start()
}`}</pre>
          )}

          <button
            onClick={() => setShowBackend(!showBackend)}
            className="flex w-full items-center justify-between rounded-lg border border-slate-200 bg-slate-50 px-4 py-3 text-left text-sm font-medium text-navy-800 hover:bg-slate-100"
          >
            <span className="flex items-center gap-2"><Terminal size={16} /> Backend integration (Node.js + Express + Fabric Gateway)</span>
            <span className="text-xs text-slate-500">{showBackend ? 'Hide' : 'Show'}</span>
          </button>
          {showBackend && (
            <pre className="overflow-x-auto rounded-lg bg-navy-900 p-4 text-xs text-navy-50 font-mono leading-relaxed">{`// server/fabric.js — connect to a real Fabric network.
// Only enables REAL FABRIC MODE after a genuine committed transaction verifies.
import { signers, connect, Gateway } from '@hyperledger/fabric-gateway';
import * as crypto from 'crypto';
import { readFileSync } from 'fs';

const cert = readFileSync(process.env.FABRIC_CERT_PATH);
const key = readFileSync(process.env.FABRIC_KEY_PATH);
const tlsCert = readFileSync(process.env.FABRIC_TLS_CERT_PATH);

const identity = { mspId: process.env.FABRIC_MSP_ID, credentials: cert };
const signer = signers.newPrivateKeySigner(crypto.createPrivateKey(key));

export async function getGateway() {
  const client = await connect({
    endpoint: process.env.FABRIC_ENDPOINT,
    identity,
    signer,
    tlsRootCertificates: tlsCert,
  });
  return client;
}

// Submit a transaction and wait for commit status. Distinguish
// PENDING / CONFIRMED / FAILED / UNKNOWN. Use idempotency keys.
export async function submitTx(name, args, idempotencyKey) {
  const gw = await getGateway();
  const network = gw.getNetwork(process.env.FABRIC_CHANNEL);
  const contract = network.getContract('ipledger');
  const tx = contract.createTransaction(name);
  if (idempotencyKey) tx.setTransient({ idempotencyKey: Buffer.from(idempotencyKey) });
  const result = await tx.submit(...args);            // throws on endorsement failure
  const status = await tx.getStatus();               // COMMITTED or NOT_COMMITTED
  return { result: result.toString(), status, txId: tx.getTransactionId() };
}

// Verify connection by reading a known key — never enable FABRIC mode
// based on a mocked or simulated response.
export async function verifyConnection() {
  try {
    const gw = await getGateway();
    const network = gw.getNetwork(process.env.FABRIC_CHANNEL);
    const contract = network.getContract('ipledger');
    const result = await contract.evaluateTransaction('GetInventionHistory', '__probe__');
    // A real evaluate reaching peers proves the network is live.
    return true;
  } catch { return false; }
}`}</pre>
          )}

          <button
            onClick={() => setShowEnv(!showEnv)}
            className="flex w-full items-center justify-between rounded-lg border border-slate-200 bg-slate-50 px-4 py-3 text-left text-sm font-medium text-navy-800 hover:bg-slate-100"
          >
            <span className="flex items-center gap-2"><Server size={16} /> Environment variables & setup instructions</span>
            <span className="text-xs text-slate-500">{showEnv ? 'Hide' : 'Show'}</span>
          </button>
          {showEnv && (
            <div className="space-y-3">
              <pre className="overflow-x-auto rounded-lg bg-navy-900 p-4 text-xs text-navy-50 font-mono leading-relaxed">{`# .env.example — Fabric integration (local deployment only)
# Do NOT expose these to the browser. Keep in backend .env only.
FABRIC_ENDPOINT=localhost:7051
FABRIC_CHANNEL=mychannel
FABRIC_MSP_ID=Org1MSP
FABRIC_CERT_PATH=./crypto/peerOrganizations/org1.example.com/users/User1@org1.example.com/msp/signcerts/cert.pem
FABRIC_KEY_PATH=./crypto/peerOrganizations/org1.example.com/users/User1@org1.example.com/msp/keystore/priv_sk
FABRIC_TLS_CERT_PATH=./crypto/peerOrganizations/org1.example.com/peers/peer0.org1.example.com/tls/ca.crt

# Supabase (pre-populated in hosted environment)
VITE_SUPABASE_URL=
VITE_SUPABASE_ANON_KEY=
SUPABASE_SERVICE_ROLE_KEY=`}</pre>
              <div className="rounded-lg border border-slate-200 bg-white p-4 text-sm text-slate-700 space-y-2">
                <p className="font-semibold text-navy-800">Local setup (test-network):</p>
                <ol className="list-decimal pl-5 space-y-1 text-xs">
                  <li>Install Docker and Docker Compose.</li>
                  <li>Clone <code className="bg-slate-100 px-1 rounded">hyperledger/fabric-samples</code> and run <code className="bg-slate-100 px-1 rounded">./network.sh up createChannel -c mychannel -ca</code>.</li>
                  <li>Deploy the chaincode above with <code className="bg-slate-100 px-1 rounded">./network.sh deployCC -ccn ipledger -ccp ../ipledger-chaincode -ccl go</code>.</li>
                  <li>Copy user crypto materials into <code className="bg-slate-100 px-1 rounded">./crypto/</code> and set the env vars above in the backend <code>.env</code>.</li>
                  <li>Start the Node.js backend: <code className="bg-slate-100 px-1 rounded">npm run server</code>. It calls <code>verifyConnection()</code>; only on success does it enable REAL FABRIC MODE.</li>
                  <li>Start the frontend: <code className="bg-slate-100 px-1 rounded">npm run dev</code>.</li>
                </ol>
                <p className="text-xs text-amber-700 mt-2">
                  Never expose Fabric private keys, certificates, enrollment secrets, or backend
                  credentials to the browser. All Fabric operations go through the backend.
                </p>
              </div>
            </div>
          )}
        </div>
      </Card>

      {/* Architecture note */}
      <Card className="p-5">
        <h3 className="text-base font-semibold text-navy-800 mb-2">Hosted Environment — Alternative Architecture</h3>
        <p className="text-sm text-slate-600">
          This Bolt-hosted deployment runs a React + TypeScript frontend backed by a Supabase
          PostgreSQL database. A separate Node.js/Express backend and Docker (required for a real
          Fabric network) are not available in the hosted tier, so the application runs in
          SIMULATION MODE here. The simulation layer implements every workflow (registration,
          approval, licensing, transfers, disputes, audit history) with clearly-labeled simulated
          transaction IDs. The Fabric chaincode, backend integration code, and setup instructions
          above are provided for local deployment. A successful simulation never activates
          REAL FABRIC MODE.
        </p>
        <div className="mt-3 grid grid-cols-2 gap-3 text-xs sm:grid-cols-4">
          <div className="rounded-lg bg-slate-50 p-3"><p className="font-semibold text-navy-800">Frontend</p><p className="text-slate-600">React + TS + Tailwind</p></div>
          <div className="rounded-lg bg-slate-50 p-3"><p className="font-semibold text-navy-800">Database</p><p className="text-slate-600">Supabase (Postgres)</p></div>
          <div className="rounded-lg bg-slate-50 p-3"><p className="font-semibold text-navy-800">Hashing</p><p className="text-slate-600">Web Crypto SHA-256</p></div>
          <div className="rounded-lg bg-slate-50 p-3"><p className="font-semibold text-navy-800">Blockchain</p><p className="text-slate-600">Simulation (Fabric optional/local)</p></div>
        </div>
      </Card>

      <div className="rounded-lg border border-amber-200 bg-amber-50 px-4 py-3 text-xs text-amber-800">
        <strong>Demo notice:</strong> Authentication here is a labeled demo role switcher, not
        production-grade security. For real deployments, wire the backend to Hyperledger Fabric
        identity (MSP) and enforce role-based access in chaincode.
      </div>
    </div>
  );
}
