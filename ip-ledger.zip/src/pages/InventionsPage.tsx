import { useEffect, useState, useCallback } from 'react';
import { supabase } from '@/lib/supabase';
import type { Invention, DocumentRecord } from '@/lib/supabase';
import { registerInvention, validateFiles, transitionInvention } from '@/lib/inventions';
import type { Role } from '@/lib/supabase';
import { Card, Badge, Button, Spinner, EmptyState, Modal, Input, TextArea, Select } from '@/components/ui';
import { useApp } from '@/lib/appState';
import { FileText, Plus, Search, FileCheck2, AlertTriangle, Hash, ArrowRight, X } from 'lucide-react';
import { loadSampleData, clearAllData } from '@/lib/sampleData';

export function InventionsPage() {
  const role = useApp((s) => s.role);
  const showToast = useApp((s) => s.showToast);
  const [inventions, setInventions] = useState<Invention[]>([]);
  const [docsMap, setDocsMap] = useState<Record<string, DocumentRecord[]>>({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [showRegister, setShowRegister] = useState(false);
  const [selected, setSelected] = useState<Invention | null>(null);

  const fetchInventions = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const { data, error } = await supabase
        .from('inventions')
        .select('*')
        .order('created_at', { ascending: false });
      if (error) throw error;
      const invs = (data as Invention[]) ?? [];
      setInventions(invs);
      // Fetch docs for each
      const map: Record<string, DocumentRecord[]> = {};
      for (const inv of invs) {
        const { data: docs } = await supabase
          .from('documents')
          .select('*')
          .eq('invention_id', inv.id)
          .order('version', { ascending: true });
        map[inv.id] = (docs as DocumentRecord[]) ?? [];
      }
      setDocsMap(map);
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchInventions();
  }, [fetchInventions]);

  const filtered = inventions.filter((i) => {
    const matchesSearch =
      !search ||
      i.title.toLowerCase().includes(search.toLowerCase()) ||
      i.inventor_name.toLowerCase().includes(search.toLowerCase()) ||
      i.internal_id.toLowerCase().includes(search.toLowerCase());
    const matchesStatus = statusFilter === 'ALL' || i.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const handleLoadSample = async () => {
    try {
      const res = await loadSampleData();
      showToast('info', `Sample data: ${res.created} created, ${res.skipped} already existed.`);
      fetchInventions();
    } catch (e) {
      showToast('error', `Failed to load sample data: ${e instanceof Error ? e.message : String(e)}`);
    }
  };

  const handleClear = async () => {
    if (!confirm('Clear ALL data? This removes inventions, documents, licenses, transfers, disputes, and audit events.')) return;
    try {
      await clearAllData();
      showToast('success', 'All data cleared.');
      fetchInventions();
    } catch (e) {
      showToast('error', `Failed to clear: ${e instanceof Error ? e.message : String(e)}`);
    }
  };

  return (
    <div className="space-y-4">
      {/* Controls */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex flex-1 flex-col gap-2 sm:flex-row">
          <div className="relative flex-1 max-w-xs">
            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Search title, inventor, ID..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full rounded-lg border border-slate-300 pl-9 pr-3 py-2 text-sm outline-none focus:border-navy-500 focus:ring-2 focus:ring-navy-100"
            />
          </div>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="rounded-lg border border-slate-300 px-3 py-2 text-sm bg-white outline-none focus:border-navy-500"
          >
            <option value="ALL">All statuses</option>
            {['PROPOSED','PENDING_APPROVAL','APPROVED','RECORDED','COMPLETED','REJECTED','DISPUTED'].map((s) => (
              <option key={s} value={s}>{s}</option>
            ))}
          </select>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={handleLoadSample}>Load sample data</Button>
          <Button variant="ghost" size="sm" onClick={handleClear}>Clear all</Button>
          <Button size="sm" onClick={() => setShowRegister(true)}>
            <Plus size={16} /> Register
          </Button>
        </div>
      </div>

      {error && (
        <div className="rounded-lg border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-700">
          <AlertTriangle size={16} className="inline mr-2" />
          {error}
        </div>
      )}

      {loading ? (
        <div className="flex justify-center py-12"><Spinner className="h-6 w-6" /></div>
      ) : filtered.length === 0 ? (
        <EmptyState
          icon={<FileText size={40} />}
          title="No invention records"
          description="Register a new invention or load demo data to get started."
          action={<Button size="sm" onClick={() => setShowRegister(true)}><Plus size={16} /> Register Invention</Button>}
        />
      ) : (
        <Card className="overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-slate-50">
                <tr className="text-left text-xs uppercase text-slate-500">
                  <th className="px-4 py-3 font-medium">Internal ID</th>
                  <th className="px-4 py-3 font-medium">Title</th>
                  <th className="px-4 py-3 font-medium">Inventor</th>
                  <th className="px-4 py-3 font-medium">Organization</th>
                  <th className="px-4 py-3 font-medium">Docs</th>
                  <th className="px-4 py-3 font-medium">Status</th>
                  <th className="px-4 py-3 font-medium">Created</th>
                  <th className="px-4 py-3 font-medium"></th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((inv) => (
                  <tr key={inv.id} className="border-t border-slate-100 hover:bg-slate-50">
                    <td className="px-4 py-3 font-mono text-xs text-navy-700">{inv.internal_id}</td>
                    <td className="px-4 py-3 font-medium text-navy-800">{inv.title}</td>
                    <td className="px-4 py-3 text-slate-700">{inv.inventor_name}</td>
                    <td className="px-4 py-3 text-slate-600">{inv.organization ?? '—'}</td>
                    <td className="px-4 py-3">
                      <Badge tone="info">{docsMap[inv.id]?.length ?? 0}</Badge>
                    </td>
                    <td className="px-4 py-3">
                      <StatusBadge status={inv.status} />
                    </td>
                    <td className="px-4 py-3 text-xs text-slate-500">{new Date(inv.created_at).toLocaleDateString()}</td>
                    <td className="px-4 py-3 text-right">
                      <Button variant="ghost" size="sm" onClick={() => setSelected(inv)}>
                        Details <ArrowRight size={14} />
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      )}

      {showRegister && (
        <RegisterModal
          onClose={() => setShowRegister(false)}
          onSuccess={() => {
            setShowRegister(false);
            fetchInventions();
          }}
          role={role}
        />
      )}

      {selected && (
        <InventionDetailModal
          invention={selected}
          documents={docsMap[selected.id] ?? []}
          onClose={() => setSelected(null)}
          onUpdated={(inv) => {
            setSelected(inv);
            fetchInventions();
          }}
          role={role}
        />
      )}
    </div>
  );
}

function StatusBadge({ status }: { status: Invention['status'] }) {
  const tones: Record<string, 'neutral' | 'info' | 'warning' | 'success' | 'error'> = {
    PROPOSED: 'neutral',
    PENDING_APPROVAL: 'warning',
    APPROVED: 'success',
    RECORDED: 'info',
    COMPLETED: 'success',
    REJECTED: 'error',
    DISPUTED: 'error',
  };
  return <Badge tone={tones[status] ?? 'neutral'}>{status}</Badge>;
}

function RegisterModal({ onClose, onSuccess, role }: { onClose: () => void; onSuccess: () => void; role: Role }) {
  const showToast = useApp((s) => s.showToast);
  const [form, setForm] = useState({
    title: '',
    description: '',
    inventor_name: '',
    collaborators: '',
    organization: '',
    jurisdiction: '',
    claimed_owner: '',
    patent_application_number: '',
    notes: '',
  });
  const [files, setFiles] = useState<File[]>([]);
  const [submitting, setSubmitting] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [result, setResult] = useState<{ internal_id: string; documents: { filename: string; sha256_hash: string }[] } | null>(null);

  const validate = () => {
    const e: Record<string, string> = {};
    if (!form.title.trim()) e.title = 'Title is required';
    if (!form.inventor_name.trim()) e.inventor_name = 'Inventor name is required';
    if (!form.organization.trim()) e.organization = 'Organization is required';
    if (!form.jurisdiction.trim()) e.jurisdiction = 'Jurisdiction is required';
    if (!form.claimed_owner.trim()) e.claimed_owner = 'Claimed owner is required';
    const fileErrs = validateFiles(files);
    if (fileErrs.length > 0) e.files = fileErrs[0].reason;
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const submit = async () => {
    if (!validate()) return;
    setSubmitting(true);
    try {
      const res = await registerInvention({
        ...form,
        collaborators: form.collaborators.split(',').map((s) => s.trim()),
        files,
        actorRole: role,
      });
      setResult({
        internal_id: res.invention.internal_id,
        documents: res.documents.map((d) => ({ filename: d.filename, sha256_hash: d.sha256_hash })),
      });
      showToast('success', `Invention ${res.invention.internal_id} registered. Status: PROPOSED.`);
      onSuccess();
    } catch (e) {
      showToast('error', e instanceof Error ? e.message : String(e));
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Modal open onClose={onClose} title="Register New Invention" wide>
      {result ? (
        <div className="space-y-4">
          <div className="rounded-lg border border-emerald-200 bg-emerald-50 p-4">
            <h4 className="font-semibold text-emerald-800 flex items-center gap-2">
              <FileCheck2 size={18} /> Invention Registered
            </h4>
            <p className="text-sm text-emerald-700 mt-1">
              Internal ID: <span className="font-mono font-bold">{result.internal_id}</span>
            </p>
            <p className="text-xs text-emerald-600 mt-1">Status: PROPOSED. Awaiting submission for approval.</p>
          </div>
          {result.documents.length > 0 && (
            <div>
              <h5 className="text-sm font-semibold text-navy-800 mb-2">Document Hashes (SHA-256)</h5>
              <div className="space-y-2">
                {result.documents.map((d, i) => (
                  <div key={i} className="rounded-lg border border-slate-200 bg-slate-50 p-3">
                    <div className="flex items-center gap-2 text-sm font-medium text-navy-700">
                      <Hash size={14} /> {d.filename}
                    </div>
                    <p className="mt-1 font-mono text-xs text-slate-600 break-all">{d.sha256_hash}</p>
                  </div>
                ))}
              </div>
            </div>
          )}
          <p className="text-xs text-slate-500">
            Note: File contents are NOT uploaded to public storage — only their SHA-256 hashes and
            metadata are persisted. Do not put complete patent documents on the blockchain.
          </p>
          <Button onClick={onClose}>Close</Button>
        </div>
      ) : (
        <div className="space-y-4">
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <Input label="Invention Title *" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} error={errors.title} />
            <Input label="Inventor Name *" value={form.inventor_name} onChange={(e) => setForm({ ...form, inventor_name: e.target.value })} error={errors.inventor_name} />
            <Input label="Collaborators (comma-separated)" value={form.collaborators} onChange={(e) => setForm({ ...form, collaborators: e.target.value })} />
            <Input label="Organization *" value={form.organization} onChange={(e) => setForm({ ...form, organization: e.target.value })} error={errors.organization} />
            <Select label="Jurisdiction *" value={form.jurisdiction} onChange={(e) => setForm({ ...form, jurisdiction: e.target.value })} error={errors.jurisdiction}>
              <option value="">Select...</option>
              <option>United States</option>
              <option>European Union</option>
              <option>United Kingdom</option>
              <option>Canada</option>
              <option>Australia</option>
              <option>Japan</option>
              <option>India</option>
              <option>Other</option>
            </Select>
            <Input label="Claimed Owner *" value={form.claimed_owner} onChange={(e) => setForm({ ...form, claimed_owner: e.target.value })} error={errors.claimed_owner} />
            <Input label="Patent Application Number (optional)" value={form.patent_application_number} onChange={(e) => setForm({ ...form, patent_application_number: e.target.value })} />
          </div>
          <TextArea label="Description" rows={3} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
          <TextArea label="Supporting Notes" rows={2} value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} />

          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Document Uploads (PDF, text, images; max 20MB)</label>
            <input
              type="file"
              multiple
              onChange={(e) => setFiles(Array.from(e.target.files ?? []))}
              className="block w-full text-sm text-slate-500 file:mr-3 file:rounded-lg file:border-0 file:bg-navy-50 file:px-4 file:py-2 file:text-sm file:font-medium file:text-navy-700 hover:file:bg-navy-100"
            />
            {files.length > 0 && (
              <ul className="mt-2 space-y-1">
                {files.map((f, i) => (
                  <li key={i} className="flex items-center justify-between rounded bg-slate-50 px-3 py-1.5 text-xs">
                    <span className="text-slate-700">{f.name} ({(f.size / 1024).toFixed(1)} KB)</span>
                    <button onClick={() => setFiles(files.filter((_, idx) => idx !== i))} className="text-slate-400 hover:text-rose-600">
                      <X size={14} />
                    </button>
                  </li>
                ))}
              </ul>
            )}
            {errors.files && <p className="mt-1 text-xs text-rose-600">{errors.files}</p>}
            <p className="mt-1 text-xs text-slate-500">
              SHA-256 hashes will be calculated client-side. Only hashes are stored — never file contents.
            </p>
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <Button variant="outline" onClick={onClose}>Cancel</Button>
            <Button onClick={submit} disabled={submitting}>
              {submitting ? <Spinner /> : null}
              {submitting ? 'Registering...' : 'Register Invention'}
            </Button>
          </div>
        </div>
      )}
    </Modal>
  );
}

function InventionDetailModal({
  invention,
  documents,
  onClose,
  onUpdated,
  role,
}: {
  invention: Invention;
  documents: DocumentRecord[];
  onClose: () => void;
  onUpdated: (inv: Invention) => void;
  role: Role;
}) {
  const showToast = useApp((s) => s.showToast);
  const [busy, setBusy] = useState(false);
  const [inv, setInv] = useState(invention);

  const canApproveRole = ['Institution/IP Administrator', 'Auditor'].includes(role);
  const canDisputeRole = ['Rights Holder', 'Institution/IP Administrator', 'Auditor', 'Licensee'].includes(role);

  const doTransition = async (newStatus: Invention['status']) => {
    setBusy(true);
    try {
      const updated = await transitionInvention(inv, newStatus, role);
      setInv(updated);
      onUpdated(updated);
      showToast('success', `Status changed to ${newStatus}.`);
    } catch (e) {
      showToast('error', e instanceof Error ? e.message : String(e));
    } finally {
      setBusy(false);
    }
  };

  return (
    <Modal open onClose={onClose} title={inv.title} wide>
      <div className="space-y-4">
        <div className="flex items-center gap-2 flex-wrap">
          <span className="font-mono text-xs text-navy-700">{inv.internal_id}</span>
          <StatusBadge status={inv.status} />
          {inv.patent_application_number && <Badge tone="info">Patent: {inv.patent_application_number}</Badge>}
        </div>

        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 text-sm">
          <div><span className="text-slate-500">Inventor:</span> <span className="font-medium text-navy-800">{inv.inventor_name}</span></div>
          <div><span className="text-slate-500">Organization:</span> <span className="font-medium text-navy-800">{inv.organization ?? '—'}</span></div>
          <div><span className="text-slate-500">Jurisdiction:</span> <span className="font-medium text-navy-800">{inv.jurisdiction ?? '—'}</span></div>
          <div><span className="text-slate-500">Claimed Owner:</span> <span className="font-medium text-navy-800">{inv.claimed_owner ?? '—'}</span></div>
          <div><span className="text-slate-500">Created by:</span> <span className="font-medium text-navy-800">{inv.created_by_role}</span></div>
          <div><span className="text-slate-500">Created:</span> <span className="font-medium text-navy-800">{new Date(inv.created_at).toLocaleString()}</span></div>
        </div>

        {inv.collaborators && inv.collaborators.length > 0 && (
          <div>
            <span className="text-sm text-slate-500">Collaborators:</span>
            <div className="mt-1 flex flex-wrap gap-1.5">
              {inv.collaborators.map((c, i) => <Badge key={i} tone="neutral">{c}</Badge>)}
            </div>
          </div>
        )}

        {inv.description && (
          <div>
            <h5 className="text-sm font-semibold text-navy-800 mb-1">Description</h5>
            <p className="text-sm text-slate-700 whitespace-pre-wrap">{inv.description}</p>
          </div>
        )}

        {/* Documents with hashes */}
        <div>
          <h5 className="text-sm font-semibold text-navy-800 mb-2">Documents & Hashes</h5>
          {documents.length === 0 ? (
            <p className="text-xs text-slate-500">No documents attached.</p>
          ) : (
            <div className="space-y-2">
              {documents.map((d) => (
                <div key={d.id} className="rounded-lg border border-slate-200 bg-slate-50 p-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2 text-sm font-medium text-navy-700">
                      <FileText size={14} /> {d.filename}
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge tone="info">v{d.version}</Badge>
                      <span className="text-xs text-slate-500">{d.size_bytes ? `${(d.size_bytes / 1024).toFixed(1)} KB` : ''}</span>
                    </div>
                  </div>
                  <p className="mt-1.5 font-mono text-xs text-slate-600 break-all">
                    <Hash size={11} className="inline mr-1" />{d.sha256_hash}
                  </p>
                  <p className="mt-1 text-[11px] text-slate-400">Uploaded {new Date(d.uploaded_at).toLocaleString()} by {d.uploaded_by_role}</p>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Workflow actions */}
        <div className="rounded-lg border border-navy-100 bg-navy-50/50 p-4">
          <h5 className="text-sm font-semibold text-navy-800 mb-2">Ownership Workflow</h5>
          <p className="text-xs text-slate-600 mb-3">
            State machine: PROPOSED → PENDING_APPROVAL → APPROVED → RECORDED → COMPLETED.
            Alternatives: PENDING_APPROVAL → REJECTED / DISPUTED; APPROVED → DISPUTED.
          </p>
          <div className="flex flex-wrap gap-2">
            {inv.status === 'PROPOSED' && (
              <Button size="sm" variant="secondary" onClick={() => doTransition('PENDING_APPROVAL')} disabled={busy}>
                Submit for Approval
              </Button>
            )}
            {inv.status === 'PENDING_APPROVAL' && canApproveRole && (
              <>
                <Button size="sm" variant="primary" onClick={() => doTransition('APPROVED')} disabled={busy}>Approve</Button>
                <Button size="sm" variant="danger" onClick={() => doTransition('REJECTED')} disabled={busy}>Reject</Button>
              </>
            )}
            {inv.status === 'PENDING_APPROVAL' && !canApproveRole && (
              <p className="text-xs text-slate-500">Only Institution/IP Administrator or Auditor can approve/reject.</p>
            )}
            {inv.status === 'APPROVED' && canApproveRole && (
              <Button size="sm" variant="primary" onClick={() => doTransition('RECORDED')} disabled={busy}>Record to Ledger</Button>
            )}
            {inv.status === 'RECORDED' && canApproveRole && (
              <Button size="sm" variant="primary" onClick={() => doTransition('COMPLETED')} disabled={busy}>Mark Completed</Button>
            )}
            {canDisputeRole && inv.status !== 'DISPUTED' && inv.status !== 'REJECTED' && (
              <Button size="sm" variant="outline" onClick={() => doTransition('DISPUTED')} disabled={busy}>Raise Dispute</Button>
            )}
            {inv.status === 'DISPUTED' && (
              <p className="text-xs text-rose-700">Record is disputed. Transfers requiring uncontested authorization are blocked.</p>
            )}
            {inv.status === 'REJECTED' && (
              <p className="text-xs text-slate-500">Record rejected. Event history preserved in audit log.</p>
            )}
          </div>
          {busy && <div className="mt-2"><Spinner className="h-4 w-4" /></div>}
        </div>

        <div className="rounded-lg border border-amber-200 bg-amber-50 px-3 py-2 text-xs text-amber-800">
          A recorded ownership claim by this application is distinct from legally established ownership.
        </div>
      </div>
    </Modal>
  );
}
