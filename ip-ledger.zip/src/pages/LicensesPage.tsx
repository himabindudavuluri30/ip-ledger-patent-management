import { useEffect, useState, useCallback } from 'react';
import { supabase } from '@/lib/supabase';
import type { Invention, License, LicenseStatus, Role } from '@/lib/supabase';
import { createLicense, transitionLicense } from '@/lib/workflows';
import { Card, Badge, Button, Spinner, EmptyState, Modal, Input, TextArea, Select } from '@/components/ui';
import { useApp } from '@/lib/appState';
import { FileCheck2, Plus, Hash } from 'lucide-react';
import { sha256OfFile } from '@/lib/crypto';

export function LicensesPage() {
  const role = useApp((s) => s.role);
  const showToast = useApp((s) => s.showToast);
  const [licenses, setLicenses] = useState<License[]>([]);
  const [inventions, setInventions] = useState<Invention[]>([]);
  const [invMap, setInvMap] = useState<Record<string, Invention>>({});
  const [loading, setLoading] = useState(true);
  const [showCreate, setShowCreate] = useState(false);

  const fetch = useCallback(async () => {
    setLoading(true);
    try {
      const [{ data: licData }, { data: invData }] = await Promise.all([
        supabase.from('licenses').select('*').order('created_at', { ascending: false }),
        supabase.from('inventions').select('*'),
      ]);
      const invs = (invData as Invention[]) ?? [];
      setInventions(invs);
      setInvMap(Object.fromEntries(invs.map((i) => [i.id, i])));
      setLicenses((licData as License[]) ?? []);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { fetch(); }, [fetch]);

  const statusTone: Record<LicenseStatus, 'neutral' | 'info' | 'warning' | 'success' | 'error'> = {
    REQUESTED: 'warning',
    APPROVED: 'info',
    REJECTED: 'error',
    ACTIVE: 'success',
    EXPIRED: 'neutral',
    TERMINATED: 'error',
    DISPUTED: 'error',
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <p className="text-sm text-slate-600">Manage license records linked to inventions.</p>
        <Button size="sm" onClick={() => setShowCreate(true)}><Plus size={16} /> New License Request</Button>
      </div>

      {loading ? (
        <div className="flex justify-center py-12"><Spinner className="h-6 w-6" /></div>
      ) : licenses.length === 0 ? (
        <EmptyState
          icon={<FileCheck2 size={40} />}
          title="No license records"
          description="Create a license request for an invention."
          action={<Button size="sm" onClick={() => setShowCreate(true)}><Plus size={16} /> New License Request</Button>}
        />
      ) : (
        <Card className="overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-slate-50">
                <tr className="text-left text-xs uppercase text-slate-500">
                  <th className="px-4 py-3 font-medium">Invention</th>
                  <th className="px-4 py-3 font-medium">Type</th>
                  <th className="px-4 py-3 font-medium">Licensor</th>
                  <th className="px-4 py-3 font-medium">Licensee</th>
                  <th className="px-4 py-3 font-medium">Territory</th>
                  <th className="px-4 py-3 font-medium">Period</th>
                  <th className="px-4 py-3 font-medium">Status</th>
                  <th className="px-4 py-3 font-medium">Actions</th>
                </tr>
              </thead>
              <tbody>
                {licenses.map((l) => {
                  const inv = invMap[l.invention_id];
                  const canApprove = ['Institution/IP Administrator', 'Auditor', 'Rights Holder'].includes(role);
                  const invDisputed = inv?.status === 'DISPUTED';
                  return (
                    <tr key={l.id} className="border-t border-slate-100 hover:bg-slate-50">
                      <td className="px-4 py-3 font-mono text-xs text-navy-700">{inv?.internal_id ?? '—'}</td>
                      <td className="px-4 py-3 text-slate-700">{l.license_type ?? '—'}</td>
                      <td className="px-4 py-3 text-slate-700">{l.licensor ?? '—'}</td>
                      <td className="px-4 py-3 text-slate-700">{l.licensee ?? '—'}</td>
                      <td className="px-4 py-3 text-slate-700">{l.territory ?? '—'}</td>
                      <td className="px-4 py-3 text-xs text-slate-600">
                        {l.start_date ?? '—'} → {l.expiry_date ?? '—'}
                      </td>
                      <td className="px-4 py-3"><Badge tone={statusTone[l.status]}>{l.status}</Badge></td>
                      <td className="px-4 py-3">
                        <div className="flex gap-1">
                          {l.status === 'REQUESTED' && canApprove && (
                            <>
                              <Button size="sm" variant="primary" onClick={async () => {
                                try {
                                  if (!inv) throw new Error('Invention not found');
                                  await transitionLicense(l, inv, 'APPROVED', role);
                                  showToast('success', 'License approved.');
                                  fetch();
                                } catch (e) { showToast('error', e instanceof Error ? e.message : String(e)); }
                              }}>Approve</Button>
                              <Button size="sm" variant="danger" onClick={async () => {
                                try {
                                  if (!inv) throw new Error('Invention not found');
                                  await transitionLicense(l, inv, 'REJECTED', role);
                                  showToast('success', 'License rejected.');
                                  fetch();
                                } catch (e) { showToast('error', e instanceof Error ? e.message : String(e)); }
                              }}>Reject</Button>
                            </>
                          )}
                          {l.status === 'APPROVED' && canApprove && !invDisputed && (
                            <Button size="sm" variant="secondary" onClick={async () => {
                              try {
                                if (!inv) throw new Error('Invention not found');
                                await transitionLicense(l, inv, 'ACTIVE', role);
                                showToast('success', 'License activated.');
                                fetch();
                              } catch (e) { showToast('error', e instanceof Error ? e.message : String(e)); }
                            }}>Activate</Button>
                          )}
                          {l.status === 'ACTIVE' && canApprove && (
                            <Button size="sm" variant="outline" onClick={async () => {
                              try {
                                if (!inv) throw new Error('Invention not found');
                                await transitionLicense(l, inv, 'TERMINATED', role);
                                showToast('success', 'License terminated.');
                                fetch();
                              } catch (e) { showToast('error', e instanceof Error ? e.message : String(e)); }
                            }}>Terminate</Button>
                          )}
                          {l.status === 'APPROVED' && invDisputed && (
                            <span className="text-xs text-rose-600">Blocked (disputed)</span>
                          )}
                          {l.agreement_hash && (
                            <span title={l.agreement_hash} className="inline-flex items-center text-slate-400">
                              <Hash size={14} />
                            </span>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </Card>
      )}

      {showCreate && (
        <CreateLicenseModal
          inventions={inventions}
          role={role}
          onClose={() => setShowCreate(false)}
          onSuccess={() => { setShowCreate(false); fetch(); }}
        />
      )}
    </div>
  );
}

function CreateLicenseModal({ inventions, role, onClose, onSuccess }: { inventions: Invention[]; role: Role; onClose: () => void; onSuccess: () => void }) {
  const showToast = useApp((s) => s.showToast);
  const [form, setForm] = useState({
    invention_id: '',
    license_type: 'Non-exclusive',
    licensor: '',
    licensee: '',
    territory: '',
    start_date: '',
    expiry_date: '',
    notes: '',
  });
  const [agreementFile, setAgreementFile] = useState<File | null>(null);
  const [hash, setHash] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    if (agreementFile) {
      sha256OfFile(agreementFile).then(setHash).catch(() => setHash(null));
    } else {
      setHash(null);
    }
  }, [agreementFile]);

  const submit = async () => {
    const e: Record<string, string> = {};
    if (!form.invention_id) e.invention_id = 'Select an invention';
    if (!form.licensor.trim()) e.licensor = 'Required';
    if (!form.licensee.trim()) e.licensee = 'Required';
    setErrors(e);
    if (Object.keys(e).length > 0) return;
    setBusy(true);
    try {
      await createLicense({ ...form, agreementFile, actorRole: role });
      showToast('success', 'License request created.');
      onSuccess();
    } catch (err) {
      showToast('error', err instanceof Error ? err.message : String(err));
    } finally {
      setBusy(false);
    }
  };

  return (
    <Modal open onClose={onClose} title="Create License Request" wide>
      <div className="space-y-4">
        <Select label="Invention *" value={form.invention_id} onChange={(e) => setForm({ ...form, invention_id: e.target.value })} error={errors.invention_id}>
          <option value="">Select...</option>
          {inventions.map((i) => (
            <option key={i.id} value={i.id}>{i.internal_id} — {i.title}</option>
          ))}
        </Select>
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          <Select label="License Type" value={form.license_type} onChange={(e) => setForm({ ...form, license_type: e.target.value })}>
            <option>Non-exclusive</option>
            <option>Exclusive</option>
            <option>Sole</option>
            <option>Compulsatory</option>
            <option>Other</option>
          </Select>
          <Input label="Territory" value={form.territory} onChange={(e) => setForm({ ...form, territory: e.target.value })} />
          <Input label="Licensor *" value={form.licensor} onChange={(e) => setForm({ ...form, licensor: e.target.value })} error={errors.licensor} />
          <Input label="Licensee *" value={form.licensee} onChange={(e) => setForm({ ...form, licensee: e.target.value })} error={errors.licensee} />
          <Input label="Start Date" type="date" value={form.start_date} onChange={(e) => setForm({ ...form, start_date: e.target.value })} />
          <Input label="Expiry Date" type="date" value={form.expiry_date} onChange={(e) => setForm({ ...form, expiry_date: e.target.value })} />
        </div>
        <TextArea label="Notes (confidential commercial terms)" rows={2} value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} />
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">Agreement Document (optional)</label>
          <input type="file" onChange={(e) => setAgreementFile(e.target.files?.[0] ?? null)} className="block w-full text-sm text-slate-500 file:mr-3 file:rounded-lg file:border-0 file:bg-navy-50 file:px-4 file:py-2 file:text-sm file:font-medium file:text-navy-700" />
          {hash && (
            <div className="mt-2 rounded bg-slate-50 p-2">
              <p className="text-xs font-medium text-slate-500">Agreement SHA-256:</p>
              <p className="font-mono text-xs text-navy-700 break-all">{hash}</p>
            </div>
          )}
          <p className="mt-1 text-xs text-slate-500">Only the agreement hash is stored, not the file content.</p>
        </div>
        <div className="flex justify-end gap-2 pt-2">
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button onClick={submit} disabled={busy}>{busy ? <Spinner /> : null}Create Request</Button>
        </div>
      </div>
    </Modal>
  );
}
