import { useEffect, useState, useCallback } from 'react';
import { supabase } from '@/lib/supabase';
import type { Invention, Transfer, TransferStatus, Role } from '@/lib/supabase';
import { createTransfer, transitionTransfer } from '@/lib/workflows';
import { Card, Badge, Button, Spinner, EmptyState, Modal, Input, TextArea, Select } from '@/components/ui';
import { useApp } from '@/lib/appState';
import { ArrowLeftRight, Plus, Hash, AlertTriangle } from 'lucide-react';
import { sha256OfFile } from '@/lib/crypto';

export function TransfersPage() {
  const role = useApp((s) => s.role);
  const showToast = useApp((s) => s.showToast);
  const [transfers, setTransfers] = useState<Transfer[]>([]);
  const [inventions, setInventions] = useState<Invention[]>([]);
  const [invMap, setInvMap] = useState<Record<string, Invention>>({});
  const [loading, setLoading] = useState(true);
  const [showCreate, setShowCreate] = useState(false);

  const fetch = useCallback(async () => {
    setLoading(true);
    try {
      const [{ data: tData }, { data: invData }] = await Promise.all([
        supabase.from('transfers').select('*').order('created_at', { ascending: false }),
        supabase.from('inventions').select('*'),
      ]);
      const invs = (invData as Invention[]) ?? [];
      setInventions(invs);
      setInvMap(Object.fromEntries(invs.map((i) => [i.id, i])));
      setTransfers((tData as Transfer[]) ?? []);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { fetch(); }, [fetch]);

  const statusTone: Record<TransferStatus, 'neutral' | 'info' | 'warning' | 'success' | 'error'> = {
    REQUESTED: 'warning',
    APPROVED: 'info',
    REJECTED: 'error',
    COMPLETED: 'success',
    DISPUTED: 'error',
    CANCELLED: 'neutral',
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <p className="text-sm text-slate-600">Ownership transfer requests and approvals.</p>
        <Button size="sm" onClick={() => setShowCreate(true)}><Plus size={16} /> New Transfer Request</Button>
      </div>

      <div className="rounded-lg border border-amber-200 bg-amber-50 px-4 py-2.5 text-xs text-amber-800">
        Transfers recorded by this application do not automatically assert legal transfer effectiveness.
        External filings or registrations may be required by applicable law.
      </div>

      {loading ? (
        <div className="flex justify-center py-12"><Spinner className="h-6 w-6" /></div>
      ) : transfers.length === 0 ? (
        <EmptyState
          icon={<ArrowLeftRight size={40} />}
          title="No transfer requests"
          description="Create a transfer request for an invention."
          action={<Button size="sm" onClick={() => setShowCreate(true)}><Plus size={16} /> New Transfer Request</Button>}
        />
      ) : (
        <Card className="overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-slate-50">
                <tr className="text-left text-xs uppercase text-slate-500">
                  <th className="px-4 py-3 font-medium">Invention</th>
                  <th className="px-4 py-3 font-medium">Current Holder</th>
                  <th className="px-4 py-3 font-medium">Proposed Recipient</th>
                  <th className="px-4 py-3 font-medium">Status</th>
                  <th className="px-4 py-3 font-medium">Created</th>
                  <th className="px-4 py-3 font-medium">Actions</th>
                </tr>
              </thead>
              <tbody>
                {transfers.map((t) => {
                  const inv = invMap[t.invention_id];
                  const canApprove = ['Institution/IP Administrator', 'Auditor', 'Rights Holder'].includes(role);
                  const invDisputed = inv?.status === 'DISPUTED';
                  return (
                    <tr key={t.id} className="border-t border-slate-100 hover:bg-slate-50">
                      <td className="px-4 py-3 font-mono text-xs text-navy-700">{inv?.internal_id ?? '—'}</td>
                      <td className="px-4 py-3 text-slate-700">{t.current_holder ?? '—'}</td>
                      <td className="px-4 py-3 text-slate-700">{t.proposed_recipient ?? '—'}</td>
                      <td className="px-4 py-3"><Badge tone={statusTone[t.status]}>{t.status}</Badge></td>
                      <td className="px-4 py-3 text-xs text-slate-500">{new Date(t.created_at).toLocaleDateString()}</td>
                      <td className="px-4 py-3">
                        <div className="flex gap-1">
                          {t.status === 'REQUESTED' && canApprove && (
                            <>
                              <Button size="sm" variant="primary" onClick={async () => {
                                try {
                                  if (!inv) throw new Error('Invention not found');
                                  await transitionTransfer(t, inv, 'APPROVED', role);
                                  showToast('success', 'Transfer approved.');
                                  fetch();
                                } catch (e) { showToast('error', e instanceof Error ? e.message : String(e)); }
                              }}>Approve</Button>
                              <Button size="sm" variant="danger" onClick={async () => {
                                try {
                                  if (!inv) throw new Error('Invention not found');
                                  await transitionTransfer(t, inv, 'REJECTED', role);
                                  showToast('success', 'Transfer rejected.');
                                  fetch();
                                } catch (e) { showToast('error', e instanceof Error ? e.message : String(e)); }
                              }}>Reject</Button>
                            </>
                          )}
                          {t.status === 'APPROVED' && canApprove && (
                            <Button size="sm" variant="secondary" onClick={async () => {
                              try {
                                if (!inv) throw new Error('Invention not found');
                                await transitionTransfer(t, inv, 'COMPLETED', role);
                                showToast('success', 'Transfer completed.');
                                fetch();
                              } catch (e) { showToast('error', e instanceof Error ? e.message : String(e)); }
                            }}>Complete</Button>
                          )}
                          {t.status === 'APPROVED' && invDisputed && (
                            <span className="text-xs text-rose-600 inline-flex items-center gap-1">
                              <AlertTriangle size={12} /> Blocked (disputed)
                            </span>
                          )}
                          {t.agreement_hash && (
                            <span title={t.agreement_hash} className="inline-flex items-center text-slate-400">
                              <Hash size={14} />
                            </span>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </Card>
      )}

      {showCreate && (
        <CreateTransferModal
          inventions={inventions}
          role={role}
          onClose={() => setShowCreate(false)}
          onSuccess={() => { setShowCreate(false); fetch(); }}
        />
      )}
    </div>
  );
}

function CreateTransferModal({ inventions, role, onClose, onSuccess }: { inventions: Invention[]; role: Role; onClose: () => void; onSuccess: () => void }) {
  const showToast = useApp((s) => s.showToast);
  const [form, setForm] = useState({
    invention_id: '',
    current_holder: '',
    proposed_recipient: '',
    notes: '',
  });
  const [agreementFile, setAgreementFile] = useState<File | null>(null);
  const [hash, setHash] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    if (agreementFile) {
      sha256OfFile(agreementFile).then(setHash).catch(() => setHash(null));
    } else setHash(null);
  }, [agreementFile]);

  const submit = async () => {
    const e: Record<string, string> = {};
    if (!form.invention_id) e.invention_id = 'Select an invention';
    if (!form.current_holder.trim()) e.current_holder = 'Required';
    if (!form.proposed_recipient.trim()) e.proposed_recipient = 'Required';
    setErrors(e);
    if (Object.keys(e).length > 0) return;
    setBusy(true);
    try {
      await createTransfer({ ...form, agreementFile, actorRole: role });
      showToast('success', 'Transfer request created.');
      onSuccess();
    } catch (err) {
      showToast('error', err instanceof Error ? err.message : String(err));
    } finally {
      setBusy(false);
    }
  };

  return (
    <Modal open onClose={onClose} title="Create Transfer Request" wide>
      <div className="space-y-4">
        <Select label="Invention *" value={form.invention_id} onChange={(e) => setForm({ ...form, invention_id: e.target.value })} error={errors.invention_id}>
          <option value="">Select...</option>
          {inventions.map((i) => (
            <option key={i.id} value={i.id}>{i.internal_id} — {i.title}</option>
          ))}
        </Select>
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          <Input label="Current Holder / Claim Reference *" value={form.current_holder} onChange={(e) => setForm({ ...form, current_holder: e.target.value })} error={errors.current_holder} />
          <Input label="Proposed Recipient *" value={form.proposed_recipient} onChange={(e) => setForm({ ...form, proposed_recipient: e.target.value })} error={errors.proposed_recipient} />
        </div>
        <TextArea label="Supporting Notes / Authorization Records" rows={3} value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} />
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">Supporting Agreement (optional)</label>
          <input type="file" onChange={(e) => setAgreementFile(e.target.files?.[0] ?? null)} className="block w-full text-sm text-slate-500 file:mr-3 file:rounded-lg file:border-0 file:bg-navy-50 file:px-4 file:py-2 file:text-sm file:font-medium file:text-navy-700" />
          {hash && (
            <div className="mt-2 rounded bg-slate-50 p-2">
              <p className="text-xs font-medium text-slate-500">Agreement SHA-256:</p>
              <p className="font-mono text-xs text-navy-700 break-all">{hash}</p>
            </div>
          )}
        </div>
        <div className="flex justify-end gap-2 pt-2">
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button onClick={submit} disabled={busy}>{busy ? <Spinner /> : null}Create Request</Button>
        </div>
      </div>
    </Modal>
  );
}
