import { useState } from 'react';
import { runAllTests, type TestResult } from '@/lib/tests';
import { Card, Badge, Button, Spinner } from '@/components/ui';
import { useApp } from '@/lib/appState';
import { FlaskConical, Play, CheckCircle2, XCircle, MinusCircle } from 'lucide-react';

export function TestsPage() {
  const mode = useApp((s) => s.mode);
  const showToast = useApp((s) => s.showToast);
  const [results, setResults] = useState<TestResult[]>([]);
  const [running, setRunning] = useState(false);
  const [hasRun, setHasRun] = useState(false);

  const run = async () => {
    setRunning(true);
    setResults([]);
    try {
      const r = await runAllTests();
      setResults(r);
      setHasRun(true);
      const pass = r.filter((t) => t.status === 'PASS').length;
      const fail = r.filter((t) => t.status === 'FAIL').length;
      const skip = r.filter((t) => t.status === 'SKIPPED').length;
      showToast('info', `Tests complete: ${pass} passed, ${fail} failed, ${skip} skipped.`);
    } catch (e) {
      showToast('error', e instanceof Error ? e.message : String(e));
    } finally {
      setRunning(false);
    }
  };

  const category = mode === 'HYPERLEDGER_FABRIC' ? 'FABRIC INTEGRATION TESTS' : 'SIMULATION TESTS';

  return (
    <div className="space-y-4">
      <div className={`rounded-lg border px-4 py-3 text-sm ${
        mode === 'HYPERLEDGER_FABRIC'
          ? 'border-emerald-200 bg-emerald-50 text-emerald-800'
          : 'border-amber-200 bg-amber-50 text-amber-800'
      }`}>
        <strong>{category}</strong> — Tests execute against the currently selected transaction mode.
        {mode === 'SIMULATED' && ' Fabric integration tests are SKIPPED and never reported as passed unless a real Fabric network is contacted.'}
      </div>

      <div className="flex items-center justify-between">
        <p className="text-sm text-slate-600">12 executable tests covering registration, hashing, verification, authorization, workflows, disputes, licensing, timeout reconciliation, and audit consistency.</p>
        <Button onClick={run} disabled={running}>
          {running ? <Spinner /> : <Play size={16} />}
          {running ? 'Running...' : 'Run Test Suite'}
        </Button>
      </div>

      {results.length > 0 && (
        <div className="grid grid-cols-3 gap-3">
          <Card className="p-3 text-center">
            <p className="text-2xl font-bold text-emerald-600">{results.filter((r) => r.status === 'PASS').length}</p>
            <p className="text-xs text-slate-500">Passed</p>
          </Card>
          <Card className="p-3 text-center">
            <p className="text-2xl font-bold text-rose-600">{results.filter((r) => r.status === 'FAIL').length}</p>
            <p className="text-xs text-slate-500">Failed</p>
          </Card>
          <Card className="p-3 text-center">
            <p className="text-2xl font-bold text-slate-500">{results.filter((r) => r.status === 'SKIPPED').length}</p>
            <p className="text-xs text-slate-500">Skipped</p>
          </Card>
        </div>
      )}

      {results.length === 0 && !running && !hasRun && (
        <Card className="p-10">
          <div className="flex flex-col items-center text-center">
            <FlaskConical size={40} className="text-slate-300 mb-3" />
            <p className="text-sm text-slate-600">Click "Run Test Suite" to execute all tests.</p>
          </div>
        </Card>
      )}

      {results.length > 0 && (
        <Card className="overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-slate-50">
                <tr className="text-left text-xs uppercase text-slate-500">
                  <th className="px-3 py-3 font-medium">#</th>
                  <th className="px-3 py-3 font-medium">Test</th>
                  <th className="px-3 py-3 font-medium">Category</th>
                  <th className="px-3 py-3 font-medium">Status</th>
                  <th className="px-3 py-3 font-medium">Expected</th>
                  <th className="px-3 py-3 font-medium">Actual</th>
                  <th className="px-3 py-3 font-medium">Timestamp</th>
                </tr>
              </thead>
              <tbody>
                {results.map((t) => (
                  <tr key={t.id} className="border-t border-slate-100 hover:bg-slate-50">
                    <td className="px-3 py-2 text-xs text-slate-500">{t.id}</td>
                    <td className="px-3 py-2 text-xs font-medium text-navy-800">{t.name}</td>
                    <td className="px-3 py-2">
                      <Badge tone={t.category === 'FABRIC INTEGRATION TESTS' ? 'info' : 'warning'}>{t.category}</Badge>
                    </td>
                    <td className="px-3 py-2">
                      {t.status === 'PASS' ? (
                        <span className="inline-flex items-center gap-1 text-xs font-medium text-emerald-700"><CheckCircle2 size={14} /> PASS</span>
                      ) : t.status === 'FAIL' ? (
                        <span className="inline-flex items-center gap-1 text-xs font-medium text-rose-700"><XCircle size={14} /> FAIL</span>
                      ) : (
                        <span className="inline-flex items-center gap-1 text-xs font-medium text-slate-500"><MinusCircle size={14} /> SKIPPED</span>
                      )}
                    </td>
                    <td className="px-3 py-2 text-xs text-slate-600">{t.expected}</td>
                    <td className="px-3 py-2 text-xs text-slate-600">
                      {t.actual}
                      {t.error && <span className="block text-rose-600 mt-0.5">{t.error}</span>}
                    </td>
                    <td className="px-3 py-2 text-xs text-slate-500">{new Date(t.timestamp).toLocaleString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      )}
    </div>
  );
}
