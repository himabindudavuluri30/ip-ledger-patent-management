import { Component, type ReactNode } from 'react';

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  message: string;
}

export class ErrorBoundary extends Component<Props, State> {
  state: State = { hasError: false, message: '' };

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, message: error.message };
  }

  componentDidCatch(error: Error) {
    console.error('IP Ledger render error:', error);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div style={{ padding: '2rem', fontFamily: 'system-ui, sans-serif', color: '#152a47' }}>
          <h1 style={{ fontSize: '1.25rem', fontWeight: 700, marginBottom: '0.5rem' }}>
            IP Ledger could not start
          </h1>
          <p style={{ fontSize: '0.9rem', color: '#475569', marginBottom: '0.75rem' }}>
            The application hit an unexpected error while rendering. Try reloading the page.
          </p>
          <pre style={{
            fontSize: '0.75rem',
            background: '#f1f5f9',
            padding: '0.75rem',
            borderRadius: '0.5rem',
            overflow: 'auto',
            color: '#334155',
            whiteSpace: 'pre-wrap',
          }}>
            {this.state.message}
          </pre>
          <button
            onClick={() => window.location.reload()}
            style={{
              marginTop: '1rem',
              padding: '0.5rem 1rem',
              background: '#285188',
              color: 'white',
              border: 'none',
              borderRadius: '0.375rem',
              cursor: 'pointer',
              fontSize: '0.875rem',
            }}
          >
            Reload
          </button>
        </div>
      );
    }
    return this.props.children;
  }
}
