import type { ReactNode } from 'react';
import { useState } from 'react';
import {
  LayoutDashboard,
  FileText,
  ShieldCheck,
  FileCheck2,
  ArrowLeftRight,
  History,
  FlaskConical,
  Settings,
  ScrollText,
  Menu,
  X,
  Link2,
  AlertTriangle,
} from 'lucide-react';
import { useApp } from '@/lib/appState';
import { ROLES } from '@/lib/supabase';
import { Badge } from './ui';

export type PageKey =
  | 'dashboard'
  | 'inventions'
  | 'verify'
  | 'licenses'
  | 'transfers'
  | 'audit'
  | 'tests'
  | 'settings';

interface NavItem {
  key: PageKey;
  label: string;
  icon: typeof LayoutDashboard;
}

const NAV: NavItem[] = [
  { key: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { key: 'inventions', label: 'Inventions', icon: FileText },
  { key: 'verify', label: 'Verify Document', icon: ShieldCheck },
  { key: 'licenses', label: 'Licenses', icon: FileCheck2 },
  { key: 'transfers', label: 'Transfers', icon: ArrowLeftRight },
  { key: 'audit', label: 'Audit History', icon: History },
  { key: 'tests', label: 'Test Suite', icon: FlaskConical },
  { key: 'settings', label: 'Settings', icon: Settings },
];

export function Layout({
  page,
  setPage,
  children,
}: {
  page: PageKey;
  setPage: (p: PageKey) => void;
  children: ReactNode;
}) {
  const role = useApp((s) => s.role);
  const setRole = useApp((s) => s.setRole);
  const mode = useApp((s) => s.mode);
  const [mobileOpen, setMobileOpen] = useState(false);

  const fabricConnected = mode === 'HYPERLEDGER_FABRIC';

  const Sidebar = (
    <aside className="flex h-full w-64 flex-col bg-navy-900 text-navy-50">
      <div className="flex items-center gap-2 border-b border-navy-800 px-5 py-4">
        <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-cyan-500 text-navy-900">
          <ScrollText size={20} />
        </div>
        <div>
          <h1 className="text-base font-bold tracking-tight text-white">IP Ledger</h1>
          <p className="text-[11px] text-navy-300">Secure IP Records & Verification</p>
        </div>
      </div>

      <nav className="flex-1 overflow-y-auto px-3 py-4">
        <p className="px-2 pb-2 text-[10px] font-semibold uppercase tracking-wider text-navy-400">Navigation</p>
        <ul className="space-y-1">
          {NAV.map((item) => {
            const active = page === item.key;
            const Icon = item.icon;
            return (
              <li key={item.key}>
                <button
                  onClick={() => {
                    setPage(item.key);
                    setMobileOpen(false);
                  }}
                  className={`flex w-full items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-colors ${
                    active
                      ? 'bg-navy-700 text-white'
                      : 'text-navy-200 hover:bg-navy-800 hover:text-white'
                  }`}
                >
                  <Icon size={18} className={active ? 'text-cyan-400' : ''} />
                  {item.label}
                </button>
              </li>
            );
          })}
        </ul>
      </nav>

      <div className="border-t border-navy-800 px-3 py-4 space-y-3">
        <div className={`rounded-lg border px-3 py-2 text-xs ${
          fabricConnected
            ? 'border-emerald-700 bg-emerald-900/30 text-emerald-300'
            : 'border-amber-700 bg-amber-900/30 text-amber-300'
        }`}>
          <div className="flex items-center gap-1.5 font-semibold">
            {fabricConnected ? <Link2 size={12} /> : <AlertTriangle size={12} />}
            {fabricConnected ? 'HYPERLEDGER FABRIC CONNECTED' : 'SIMULATION MODE'}
          </div>
          <p className="mt-1 text-[11px] opacity-80">
            {fabricConnected
              ? 'Real Fabric network verified.'
              : 'Mock blockchain records. Not real Fabric.'}
          </p>
        </div>

        <div>
          <label className="block text-[10px] font-semibold uppercase tracking-wider text-navy-400 mb-1">
            Active Role
          </label>
          <select
            value={role}
            onChange={(e) => setRole(e.target.value as typeof role)}
            className="w-full rounded-md border border-navy-700 bg-navy-800 px-2 py-1.5 text-xs text-white outline-none focus:border-cyan-500"
          >
            {ROLES.map((r) => (
              <option key={r} value={r}>{r}</option>
            ))}
          </select>
        </div>
      </div>
    </aside>
  );

  return (
    <div className="flex h-screen overflow-hidden bg-slate-50">
      {/* Desktop sidebar */}
      <div className="hidden md:block">{Sidebar}</div>

      {/* Mobile sidebar */}
      {mobileOpen && (
        <div className="fixed inset-0 z-50 md:hidden">
          <div className="absolute inset-0 bg-slate-900/60" onClick={() => setMobileOpen(false)} />
          <div className="relative h-full">{Sidebar}</div>
        </div>
      )}

      <div className="flex flex-1 flex-col overflow-hidden">
        {/* Top bar */}
        <header className="flex items-center justify-between border-b border-slate-200 bg-white px-4 py-3 md:px-6">
          <div className="flex items-center gap-3">
            <button
              className="md:hidden text-slate-600"
              onClick={() => setMobileOpen(true)}
            >
              <Menu size={22} />
            </button>
            <div>
              <h2 className="text-base font-semibold text-navy-800">
                {NAV.find((n) => n.key === page)?.label}
              </h2>
              <p className="hidden text-xs text-slate-500 sm:block">
                Blockchain-Based Patent Ownership & IP Management
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Badge tone={fabricConnected ? 'success' : 'warning'}>
              {fabricConnected ? 'FABRIC CONNECTED' : 'SIMULATION'}
            </Badge>
            <Badge tone="navy">{role}</Badge>
          </div>
        </header>

        <main className="flex-1 overflow-y-auto p-4 md:p-6">
          <div className="mx-auto max-w-7xl">
            {/* Legal notice banner */}
            <div className="mb-4 rounded-lg border border-amber-200 bg-amber-50 px-4 py-2.5 text-xs text-amber-800">
              <strong>Notice:</strong> This application supports intellectual-property record
              management and document-integrity verification. Blockchain records do not
              independently grant patents or determine legal ownership. Official patent status and
              legal rights must be verified through appropriate authorities and applicable legal
              procedures. Data shown is DEMO DATA.
            </div>
            {children}
          </div>
        </main>
      </div>
    </div>
  );
}
