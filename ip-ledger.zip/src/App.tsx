import { useState, useEffect } from 'react';
import { Layout, type PageKey } from '@/components/Layout';
import { DashboardPage } from '@/pages/DashboardPage';
import { InventionsPage } from '@/pages/InventionsPage';
import { VerifyPage } from '@/pages/VerifyPage';
import { LicensesPage } from '@/pages/LicensesPage';
import { TransfersPage } from '@/pages/TransfersPage';
import { AuditPage } from '@/pages/AuditPage';
import { TestsPage } from '@/pages/TestsPage';
import { SettingsPage } from '@/pages/SettingsPage';
import { Toast } from '@/components/ui';
import { useApp } from '@/lib/appState';

function AppShell() {
  const [page, setPage] = useState<PageKey>('dashboard');
  // Force a mode re-read on mount so the SIMULATION/FABRIC indicator is accurate.
  const refreshMode = useApp((s) => s.refreshMode);
  useEffect(() => { refreshMode(); }, [refreshMode]);

  return (
    <Layout page={page} setPage={setPage}>
      {page === 'dashboard' && <DashboardPage />}
      {page === 'inventions' && <InventionsPage />}
      {page === 'verify' && <VerifyPage />}
      {page === 'licenses' && <LicensesPage />}
      {page === 'transfers' && <TransfersPage />}
      {page === 'audit' && <AuditPage />}
      {page === 'tests' && <TestsPage />}
      {page === 'settings' && <SettingsPage />}
    </Layout>
  );
}

export default function App() {
  return (
    <>
      <AppShell />
      <Toast />
    </>
  );
}
